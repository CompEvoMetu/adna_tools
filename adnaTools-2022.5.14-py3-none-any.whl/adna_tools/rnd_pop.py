import lib as adna_lib
import fire

__version__ = '2021.3.22'  # update also in rnd_pop doc


def rnd_pop(ref: str, prefix: str, n=None, n_female=None, n_male=None,
            maf_ref=None, invert_maf=False, tag="AFngsrelate", x_chr="X",
            ind_prefix="ind", seed=None, chr_idx=0, pos_idx=1,
            id_idx=None, ref_idx=2, alt_idx=3, maf_idx=4, header=0):
    """Random population, aDNA Tools v.2021.3.22

    Generate a random population given  a reference  VCF  file  (inclusive of allele frequencies tagged, in this case
    the alternate value is assumed to be associated with the MAF) or given an alternate frequency file (hence a list of
    probabilities for the alternate value). By setting either n or  both  n_female and n_male you specify the size of
    the population. If sexes should be assigned,  they are also  appended to  the individuals' ID  (as well  as being
    stored into an external file where each  row, one per individual,  is defined by [individual ID] [F/M]). According
    to the given parameters,  a logging  file,  VCF  file, and allele  sharing coefficient  file are created.  The
    allele sharing coefficient  file  keeps track  of  the  relatedness  among the created individuals. Within the
    logging file the settings  used for  the random generation  of the  population are stored  (e.g.,  the seed number
    for the random number  generator). Within the created   VCF file,  the minor  allele frequency values (MAF) are also
    stored with the specified tag
    Output(s), varying in accordance with the given parameters:
    • VCF file with the randomized individuals
    • ASC file with the allele sharing coefficient estimates between all individuals
    • LOG file with the feedback on the randomization process
    • FAM file with the sexes of the generated individuals
    Examples (ADNA_PATH="/mnt/.../python/packages/adna_tools/"; export ADNA_PATH):
    • Documentation:
        python $ADNA_PATH/rnd_pop.py --help
    • Generate random individuals with both autosomes and X chromosome and sexes given a MAF file:
        python $ADNA_PATH/rnd_pop.py --ref maf.frq --prefix rnd_pops --n_male 3 --n_female 2 --x_chr X
        Note: The parameter x_chr could be omitted as the default value identifying X chromosome SNPs is 'X'
    • Generate random individuals with autosomes (ignoring X chromosome as no sex specifications are given) with MAF
     file as input:
        python $ADNA_PATH/rnd_pop.py --ref maf.frq --prefix rnd_pops --n 10
    • Generate random individuals with both autosomes and X chromosome and sexes given a VCF file with MAF specified
     with a tag (within the VCF file):
        python $ADNA_PATH/rnd_pop.py --ref reference.vcf --maf_ref tag --prefix rnd_pops
        --n_male 3 --n_female 2 --x_chr 23
    • Generate random  individuals with autosomes  (ignoring X chromosome as no sex specifications are given) with a
    VCF file and MAF defined via tag (within the VCF file):
        python $ADNA_PATH/rnd_pop.py --ref reference_auto.vcf --maf_ref tag --prefix rnd_pops --n 10 --x_chr 23
        Note: The parameter x_chr is specified as the  VCF file contains also X chromosome data,  when found,  since
        the sexes  are not required,  it will be ignored.  If the  VCF file does not contain  X chromosome data then
        there is no need to specify this parameter
    • Generate random individuals with autosomes and sexes with a  VCF file and MAF defined via tag  (within the VCF
    file):
        python $ADNA_PATH/rnd_pop.py --ref reference_auto.vcf --maf_ref tag --prefix rnd_pops
        --n_female 5 --n_male 9
    • Generate  random individuals with autosomes,  with no sex specified, given a  VCF file and MAF defined via tag
    (within the VCF file):
        python $ADNA_PATH/rnd_pop.py --ref reference_auto.vcf --maf_ref tag --prefix rnd_pops --n 10
    • Generate random individuals with X chromosome and sexes given a  VCF file and MAF defined via tag  (within the
    VCF file):
        python $ADNA_PATH/rnd_pop.py --ref reference_x.vcf --maf_ref tag --prefix rnd_pops
        --n_female 5 --n_male 9 --x_chr 23
    :param str ref: Reference VCF or minor allele frequency file
    :param str prefix: Prefix for output file(s)
    :param int, optional n: Number of individuals to be created (default None)
    :param int, optional n_female: Number of female individuals to be created (default None)
    :param int, optional n_male: Number of male individuals to be created (default None)
    :param optional maf_ref: Reference for minor allele frequency values:
    • None: default option, the ref file is assumed  to contains MAF info and need to specify column indices for CHR
    (chr_idx), POS (pos_idx), ID (id_idx, optional,  not considered by default),  REF (reference base, ref_idx), ALT
    (alternate base, alt_idx), MAF (minor allele frequency, maf_idx)
    • 'tag': consider the specified tag ('tag' option,  by default 'AFngsrelate') in the 'ref' file which is assumed
    to be a VCF file
    • 'rnd': random choice, 0.5 for all SNPs and the 'ref' file is assumed to be a VCF file
    :param bool, optional invert_maf: Consider (1-maf) (default False)
    :param str, optional tag: If MAFs are stored  within  the reference  VCF file,  consider the given TAG  (default
    'AFngsrelate')
    :param optional x_chr: Label associated with the X chromosome (default 'X')
    :param optional ind_prefix: Prefix for naming of individuals (default 'ind')
    :param optional seed: Seed for random number generator (default None)
    :param int, optional chr_idx: Column  index for chromosome  details for 'ref'  file with minor allele  frequency
    information (default 0)
    :param int, optional pos_idx: Column index for SNP position details  for 'ref' file  with minor allele frequency
    information (default 1)
    :param int, optional id_idx: Column index for ID details for 'ref' file with minor  allele frequency information
    (by default None, i.e., not considered)
    :param int, optional ref_idx: Column index for reference base details for 'ref' file with minor allele frequency
    information (default 2)
    :param int, optional alt_idx: Column index for alternate base details for 'ref' file with minor allele frequency
    information (default 3)
    :param int, optional maf_idx: Column index for minor allele frequency details for 'ref' file (default 4)
    :param int, optional header: Number of header lines that will be skipped (default 0)
    Note: only for 'ref'  file containing minor  allele frequency values,  not considered for VCF files  (where  all
    headers info are copied to the output file)"""

    adna_lib.rnd_pop(ref=ref, prefix=prefix, n=n, n_female=n_female, n_male=n_male,
                     maf_ref=maf_ref, invert_maf=invert_maf, tag=tag, x_chr=x_chr,
                     ind_prefix=ind_prefix, seed=seed, chr_idx=chr_idx, pos_idx=pos_idx,
                     id_idx=id_idx, ref_idx=ref_idx, alt_idx=alt_idx, maf_idx=maf_idx, header=header)


if __name__ == '__main__':
    fire.Fire(rnd_pop)
