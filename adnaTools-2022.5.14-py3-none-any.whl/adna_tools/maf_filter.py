import lib as adna_lib
import fire

__version__ = '2021.3.22'  # update also in maf_filter doc


# noinspection PyUnboundLocalVariable
def maf_filter(maf_file: str, prefix: str, maf_threshold=0.01, map_file=None, tag="AFngsrelate", maf_idx=5,
               debug=False):
    """MAF Filter, aDNA Tools v.2021.3.22

    Given  an input VCF, MAF  or alternate frequency value  file and a minor allele frequency threshold value,
    it filters all the SNPs with MAF smaller  than  the given threshold.  The frequency values are assumed  to be stored
    within the VCF file with a specific tag (default 'AFngsrelate') or, if a MAF file is passed, within a specific
    column. When a MAP file is passed, it will also be filtered to retain the one-to-one match of the SNP positions
    Examples (ADNA_PATH="/mnt/.../python/packages/adna_tools/"; export ADNA_PATH):

    • Documentation:
        python $ADNA_PATH/maf_filter.py --help

    • Filter VCF file given threshold:
        python $ADNA_PATH/maf_filter.py --maf_file pops.vcf --prefix filtered_pops --maf_threshold 0.05

    • Filter MAF file given threshold:
        python $ADNA_PATH/maf_filter.py --maf_file pops.frq --prefix filtered_pops --maf_threshold 0.05
    :param str maf_file: Input VCF or MAF file
    :param str prefix: Output prefix for the filtered VCF and MAP files
    :param str, optional maf_threshold: The minor allele frequency threshold (default 0.01)
    :param str, optional map_file: MAP file to be filtered to retain the one-to-one match with the given VCF/FRQ file
    (by default no file is passed)
    :param str, optional tag: The tag associated with the allele frequency threshold (default, 'AFngsrelate'; only for
    VCF files)
    :param int, optional maf_idx: The column index associated with the MAF values (only for MAF files)
    :param bool, optional debug: Flag to perform additional safety check for debugging purpose (default False)"""

    if ".vcf" in maf_file.lower():
        print("\nInput VCF file: {}".format(maf_file))
        maf_out = "{}.vcf".format(prefix)
        is_vcf = True
    else:
        print("\nInput MAF file: {}".format(maf_file))
        maf_out = "{}.frq".format(prefix)
        is_vcf = False
    if map_file is not None:
        print("Input MAP file: {}".format(map_file))
        map_out = "{}.map".format(prefix)
        in_map = open(map_file, "r")
        out_map = open(map_out, "w")

    print("\nMAF Threshold: {}".format(maf_threshold))
    print("All SNPs with MAF value smaller than the threshold will be discarded.")

    print("Output file:")
    print("          {}".format(maf_out))
    if map_file is not None:
        print("          {}".format(map_out))

    in_file = open(maf_file, "r")
    out_file = open(maf_out, "w")
    for line in in_file:

        if map_file is not None:
            map_line = in_map.readline()
            while map_line.startswith("#"):
                out_map.write(map_line)
                map_line = in_map.readline()

        if line.startswith("#"):  # ignore comment line
            out_file.write(line)
        else:
            values = line.split()
            if is_vcf:
                maf_value = adna_lib.extract_freq(info=values[7], tag=tag)
            else:
                maf_value = float(values[maf_idx])

            val = maf_value
            if val > 0.5:  # if an alternate frequency file is passed, it may occur to have a probability value > 0.5
                val = 1 - val
            if val >= maf_threshold:
                out_file.write(line)
                if map_file is not None:
                    out_map.write(map_line)

    in_file.close()
    out_file.close()
    if map_file is not None:
        out_map.close()
        in_map.close()

    if debug and map_file is not None:
        f_check = open(maf_out, "r")
        m_check = open(map_out, "r")
        for line in f_check:
            if not line.startswith("#"):

                m_line = m_check.readline()
                while m_line.startswith("#"):
                    m_line = m_check.readline()

                values = line.split()
                f_chr = values[0]
                f_pos = values[1]

                values = m_line.split()
                m_chr = values[0]
                m_pos = values[1]

                if not m_chr == f_chr or not m_pos == f_pos:
                    msg = "Inconsistent (chromosome, position) found: {}, {} (expected {}, {})".format(
                        m_chr, m_pos, f_chr, f_pos
                    )
                    raise ValueError(msg)

        f_check.close()
        m_check.close()


if __name__ == '__main__':
    fire.Fire(maf_filter)
