import fire
import warnings

__version__ = '2021.3.22'  # update also in msm_baseline doc


# noinspection PyUnboundLocalVariable
def normalize_msm(log_file: str, bsl_file: str, prefix: str, ignore_comp_check=False):
    """Normalize MSM, aDNA Tools v.2021.3.22

    Given a LOG file pertaining to the mismatch coefficient (see dynamic_asc documentation for more details)
    of samples of interest and given a BSL baseline mismatch coefficient file (see msm_baseline for more details)
    compute the normalized mismatch coefficient, according to the indicated mode(s).
    The normalization simply computes the ratio between the mismatch coefficient in the LOG file and the baseline
    mismatch coefficient stored in the BSL file (for each given window). If the BSL file contains multiple baseline,
    then multiple output files will be generated (one per mode)
    :param str log_file: Input file from which computing the dynamic allele sharing coefficient
    :param str bsl_file: A baseline mismatch coefficient file
    :param str prefix: Prefix for the output files (plot image and logging file)
    :param bool, optional ignore_comp_check: Ignore errors of compatibility between MSM and BSL files
    (e.g., different window sizes). By default, an error is given (flag set to False); if set to True only warning
    messages will be visualized"""

    log = open(log_file, "r")
    bas = open(bsl_file, "r")
    nor = []  # list of files to be created
    for log_line in log:
        bas_line = bas.readline()
        bas_line = bas_line.strip('\n')
        if log_line.startswith("#"):  # initialize the output(s)
            if not bas_line.startswith("#"):  # problem with the baseline file, exit
                log.close()
                bas.close()
                msg = "Unknown BSL file: '{}'. Header is missing.".format(bsl_file)
                raise ValueError(msg)
            bas_values = bas_line.split("\t")  # get the columns
            n_norm = len(bas_values) - 2
            log_values = log_line.split("\t")
            n_log = len(log_values) - 2
            for idx in range(n_norm):  # create one file for each baseline column and write its header
                nor.append(open("{}_BSL_{}.log".format(prefix, bas_values[2 + idx]), "w"))
                nor[-1].write(log_line)
        else:
            log_values = log_line.split("\t")
            bas_values = bas_line.split("\t")
            out_values = log_values[0:2]
            for idx in range(2):
                if not bas_values[idx] == log_values[idx]:
                    for idx_nor in range(n_norm):  # close files
                        nor[idx_nor].close()
                    log.close()
                    bas.close()
                    msg = "Files not compatible: BSL ({}); LOG({})".format(bas_line, log_line)
                    if ignore_comp_check:
                        warnings.warn(msg)
                    else:
                        for idx_nor in range(n_norm):  # close files
                            nor[idx_nor].close()
                        raise ValueError(msg)
            for idx_nor in range(n_norm):
                nor_values = out_values.copy()
                for idx_log in range(n_log):
                    upd_value = float(log_values[2 + idx_log]) / float(bas_values[2 + idx_nor])
                    nor_values.append(str(upd_value))
                nor_line = "\t".join(nor_values)
                nor_line = nor_line + "\n"
                nor[idx_nor].write(nor_line)
    for idx_nor in range(n_norm):  # close files
        nor[idx_nor].close()
    log.close()
    bas.close()


if __name__ == '__main__':
    fire.Fire(normalize_msm)
