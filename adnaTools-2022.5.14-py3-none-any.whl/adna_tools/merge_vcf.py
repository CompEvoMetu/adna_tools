import lib as adna_lib
import fire

__version__ = '2021.3.22'  # update also in merge_vcf doc


def merge_vcf(txt_file: str, prefix: str):
    """Merge VCF, aDNA Tools v.2021.3.2

    Given a text file containing a list of VCF files (one filename per line), it generates a new VCF file by merging
    individuals from each file. Missing positions for certain samples are marked with missing values. Common SNPs
    with conflicting reference and/or alternate values are automatically discarded (a log file provides all the details)
    NOTE: Only the commented lines of the first VCF file are retained
    :param str txt_file: Text file containing the list of VCF files to be merged
    :param str prefix: Output filename"""

    print("\nMerging VCF files...")
    ins = open_input(txt_file)  # open input files (read mode)
    out = open(prefix + ".vcf", "w")  # open output files (write mode)
    n = write_header(ins, out)  # write the header to the output file and get the total number of individuals/samples
    snps_count = write_snp_lines(ins, out, n)  # write the SNPs line
    close_files(ins, out)  # close all the used resources
    print("\nThe output file '{}.vcf' contains {:,} SNPs for {:,} samples respectively.".format(prefix, snps_count,
                                                                                                n - 9))


def open_input(txt_file: str) -> []:
    """
    Load VCF files added to the text file
    :param txt_file: Input file from which the list of VCF files is read
    :return: An array of file handlers"""

    txt = open(txt_file, "r")
    vcfs = []
    for filename in txt:
        curr_file = filename.strip('\n')
        if len(curr_file) > 0:
            vcfs.append(open(curr_file, "r"))
    txt.close()

    return vcfs


# noinspection PyTypeChecker
def write_header(ins: [], out) -> int:
    """
    Add the header to the VCF output file
    :param ins: Input file handlers
    :param out: Output VCF file
    :return: int: The number of entries for each line"""

    header = []
    first = True
    for file_in in ins:
        line = file_in.readline()
        while line.startswith("#"):
            if line.startswith("#CHROM"):
                if not header:
                    header = line.strip('\n')
                else:
                    values = line.strip('\n').split("\t")
                    ids = values[9:]
                    header = header + "\t" + "\t".join(ids)
                break
            elif first:
                out.write(line)
            line = file_in.readline()
        if first:
            first = False

    n = len(header.split("\t"))
    out.write(header + "\n")  # write the header

    return n


def close_files(ins: [], out):
    """
    Close all the files
    :param ins: Input file handlers
    :param out: Output file handler"""

    for file_in in ins:
        file_in.close()
    out.close()


# noinspection PyUnresolvedReferences,PyTypeChecker
def write_snp_lines(ins: [], out, n: int):
    """
    Write the VCF line for each SNP
    :param ins: Input file handlers
    :param out: Output file handler
    :param n: The number of entries for each line"""

    log = None
    n_shift = [-1] * len(ins)  # will contain the number of samples/individuals for each input file
    snps_count = 0  # final count of SNPs
    eof = len(ins) * [False]  # keeps track of EOF (end of file) for each input
    stop = all(eof)  # flag to stop the process once all inputs are EOF
    chromosome = 0  # keep track of the current chromosome
    snps = len(ins) * [None]  # SNPs line from each input
    print("\nChromosome")
    while not stop:
        for idx_in in range(len(ins)):  # loop over each input file
            if not eof[idx_in] and snps[idx_in] is None:  # if the file is not over, and we need to read a new line
                line = ins[idx_in].readline()
                if not line:
                    eof[idx_in] = True
                while not eof[idx_in] and line.startswith("#"):  # skip additional commented lines
                    line = ins[idx_in].readline()
                    if not line:
                        eof[idx_in] = True
                if not eof[idx_in]:  # found useful line
                    snps[idx_in] = line.strip('\n').split("\t")

        # now we have a line for each of the input file, let's choose the chromosome+position of interest
        # (unless we finished with all the files)
        stop = all(eof)
        if not stop:
            candidate_found = False  # flag to check if at least one candidate was found
            next_chromosome = None
            next_position = None
            next_reference = None
            next_alternate = None
            position = None
            reference = None  # keep the values for the selected position to verify consistency across VCFs
            alternate = None
            while not candidate_found:
                for idx_line in range(len(snps)):
                    if not eof[idx_line]:
                        values = snps[idx_line]
                        if chromosome == values[0].lower().replace("x", "23"):  # it is a candidate, check its position
                            candidate_found = True
                            if not position:
                                position = int(values[1])
                                reference = [values[3]]
                                alternate = [values[4]]
                            elif int(values[1]) < position:
                                position = int(values[1])
                                reference = [values[3]]
                                alternate = [values[4]]
                        else:  # not a current candidate, check potential for next chromosome candidate
                            check_chr = int(values[0].lower().replace("x", "23"))
                            if not next_chromosome or check_chr < next_chromosome:
                                next_chromosome = check_chr
                                next_position = int(values[1])
                                next_reference = [values[3]]
                                next_alternate = [values[4]]
                            elif check_chr == next_chromosome:
                                if int(values[1]) < next_position:
                                    next_position = int(values[1])
                                    next_reference = [values[3]]
                                    next_alternate = [values[4]]

                if not candidate_found:  # no candidate for the current chromosome, we need to switch to a new one
                    candidate_found = True
                    chromosome = next_chromosome
                    position = next_position
                    reference = next_reference
                    alternate = next_alternate
                    print(chromosome)

                chromosome = str(chromosome)
                position = str(position)

            next_values = ["."] * n
            idx_entry = 9
            for idx_line in range(len(snps)):
                if not eof[idx_line]:
                    values = snps[idx_line]
                    if n_shift[idx_line] == -1:
                        n_shift[idx_line] = len(values[9:])
                    if values[0].lower().replace("x", "23") == chromosome and values[1] == position:  # use this entry
                        reference.append(values[3])  # keep track of all reference and alternate values
                        if values[4] == ".":  # alternate is missing_value
                            for idx_ind in range(9, len(values)):  # replace alternate value with missing value
                                tmp = adna_lib.clean_snp(values[idx_ind])
                                if "1" in tmp:
                                    tmp = tmp.replace("1", ".")
                                    if len(tmp) == 1:
                                        values[idx_ind] = tmp
                                    else:
                                        new_value = tmp[0] + values[idx_ind][1] + tmp[2]
                                        if len(values[idx_ind]) > 3:
                                            new_value = new_value + values[idx_ind][3:]
                                        values[idx_ind] = new_value
                        else:
                            alternate.append(values[4])

                        if next_values[0] == ".":  # first entry for current (chromosome, position)
                            if values[4] == ".":
                                for idx_ind in range(9, len(values)):  # replace alternate value with missing value
                                    tmp = adna_lib.clean_snp(values[idx_ind])
                                    if "1" in tmp:
                                        tmp = tmp.replace("1", ".")
                                        if len(tmp) == 1:
                                            values[idx_ind] = tmp
                                        else:
                                            new_value = tmp[0] + values[idx_ind][1] + tmp[2]
                                            if len(values[idx_ind]) > 3:
                                                new_value = new_value + values[idx_ind][3:]
                                            values[idx_ind] = new_value
                            next_values[0:9] = values[0:9]
                        next_values[idx_entry:idx_entry + n_shift[idx_line]] = values[9:]
                        snps[idx_line] = None  # it has been added, remove it from SNPs list
                idx_entry += n_shift[idx_line]

            ref = reference[0]
            cur_r = None
            for r in reference:
                if not r == ref:
                    cur_r = r
                    break
            alt = alternate[0]
            cur_a = None
            for a in alternate:
                if not a == alt:
                    if alt == ".":
                        alt = a
                    else:
                        cur_a = a
                        break

            if cur_a is None and cur_r is None:  # no different values were found, ok to write the line
                next_values[3] = ref
                next_values[4] = alt
                out.write("\t".join(next_values) + "\n")
                snps_count += 1
            elif cur_r is not None:
                if log is None:
                    log = open("{}.log".format(out.name), "w")
                    log.write("CHR\tPOS\tTYPE\tVALUE1\tVALUE2\n")
                log_line = "{}\t{}\tREF\t{}\t{}\n".format(chromosome, position, ref, cur_r)
                log.write(log_line)
            else:
                if log is None:
                    log = open("{}.log".format(out.name), "w")
                    log.write("CHR\tPOS\tTYPE\tVALUE1\tVALUE2\n")
                log_line = "{}\t{}\tALT\t{}\t{}\n".format(chromosome, position, alt, cur_a)
                log.write(log_line)

    if log is not None:
        print("\nNon compatible SNPs were found and ignored. Please check '{}' log file for details".format(log.name))
        log.close()

    return snps_count


if __name__ == '__main__':
    fire.Fire(merge_vcf)
