import os
import fire
import lib as alib
import maf_filter as mf

__version__ = '2021.3.22'  # update also in make doc


def make(config: str, n: int, prefix: str, maf: str, gmap: str, m_founders: int, f_founders: int, x="X",
         export="run_sim.sh", log_file="pedigrees.log", working_folder=None, chr_idx=0, pos_idx=1, id_idx=2, ref_idx=3,
         alt_idx=4, maf_idx=5, header=0, maf_threshold=None, python="python3",
         int_map="$PEDSIM_PATH/interfere/nu_p_campbell_X.tsv"):
    """Make pedigree scripts, aDNA Tools v.2021.3.22

    Creates a Unix shell script to generate all the desired pedigrees.
    It needs a  configuration file  ('config')  and the number of samples  ('n') for each relationship specified in the
    configuration file.  Minor allele frequency ('maf') and genetic map ('gmap') files as well as the desired number of
    male  ('m_founders') and female ('f_founders') founders must also be specified. Optionally, the location of DEF and
    IDX  files  can be specified  (by default the  file are assumed to be  in the current folder).  Other relevant (yet
    optional) parameters include the tag identifying the X chromosome ('x') the name of the exported  script ('export')
    and log file   ('log_file',  in which all the combinations  of the given  pedigrees/relationships  are summarized).
    Notably, the creation of the script assumes that the variables $PEDSIM_PATH and $ADNA_PATH are defined and identify
    ped_sim and adnaTools folders respectively. By default, the interference map ('int_map') is assumed to be located in
    the ped-sim folder (i.e., $PEDSIM_PATH/interfere/nu_p_campbell_X.tsv). The configuration file contains a list of the
    relationships of interested identified by their IDX files
    Ex.: 'pedigrees.cfg':
    #par-off_2nd-cous_inb.idx
    #par-off_1st-cous_inb.idx
    #par-off_sibs_inb.idx
    #siblings.idx
    #parent-offspring.idx
    grandparent-grandchild.idx
    grandparent-grandchild_sibs_inb.idx
    grandparent-grandchild_1st-cous_inb.idx
    grandparent-grandchild_2nd-cous_inb.idx
    avuncular.idx
    avuncular_1st-cous_inb.idx
    avuncular_2nd-cous_inb.idx
    half-siblings.idx
    half-siblings_sibs_inb.idx

    Notably, the lines starting with # are considered as comments and therefore ignored

    • The abstract form of a DEF file:
        A DEF file is a definition file used by ped-sim to create pedigrees. It contains a compact form defining a
        pedigree of interest (see ped-sim website for more details on its syntax). An abstract DEF file is a
        non-complete DEF file that will be used by this script to generate all multiple combinations of sexes within a
        specified pedigree
        Ex.: Parent-Offspring pedigree - 'parent-offspring.def'

        def parent-offspring 1 2
        1 1 2 {}
        2 1 1 1:1_2 {}

        Whereas the general syntax is analogous to the one of ped-sim, there are two set of brackets '{}' that act as
        placeholders and will be used by this function to format different combinations of this pedigree (according
        to specific sexes; this syntax mimics the 'print('text {} text').format(variable)' adopted by Python).

        In this specific example, we have two possible combinations for this pedigree when we account for the sexes of
        the individuals. Specifically, for the first combination, generation 1 will have one male and one female
        individuals (i.e., the parents) and a female individual in generation 2 (i.e., the offspring of the individuals
        in generation 1). Alternatively, the second combination, generation 1 will still have one male and one female
        individuals (i.e., the parents) and a male individual in generation 2 (i.e., the offspring of the individuals
        in generation 1).

        Thus, this script will generate two combinations of the defined pedigree considering the different sexes
        each individual may assume.
        The details on the possible sexes that can be assigned to each individual are provided by the IDX file.
    • The IDX file:
      The IDX file should specify all the possible sexes each individual can have. This script will be responsible then
      to generate all possible combinations. Beyond that, it should also provide details about all the relationships of
      interest within the specific pedigree.

      Ex.: Parent-Offspring pedigree - 'parent-offspring.idx'
      NOTE: The DEF and IDX files MUST have the same name.

      <M=1 F=0>
      <G=1:[(0,1)]>
      <G=2:[0 1]>
      <IDX=0:(1,1)>
      <IDX=1:(1,2)>
      <IDX=2:(2,1)>
      #IDX1	IDX2 RELATIONSHIP DEGREE
      0	2	Parent-Offspring	1
      1	2	Parent-Offspring	1

      Notably:
      '<M=1 F=0>' simply clarifies the association between used IDs and sexes.

      '<G=1:[(0,1)]>' refers to the generation 1 in the DEF file (i.e., G=1) and provides the list of acceptable sexes
      for the individuals in generation one, i.e., in this case the two parents, only one accepted combination (0,1).
      Notably, (1,0) would only be redundant and thus can be ignored.

      '<G=2:[0 1]>' refers to the generation 2 in the DEF file (i.e., G=2). Once again, it provides the list of accepted
      sexes for the single individual, i.e., female 0 and male 1.

      Notably, if the DEF file has a generation with two or more branches/individuals the possible combinations are
      enclosed by parentheses: (0,0). A generation with a single branch/individual would not need parentheses: 0.
      To identify all possible combinations, the accepted sexes are enclosed by squared brackets:
      [(0,0) (0,1) (1,0) (1,1)] or [0 1].

      In certain cases it may be of interest to ignore a generation (i.e., its sexes combinations) in the context of the
      symmetrical evaluation. This can be indicated adding an asterisks (*) next to the generation of interest in the
      IDX file as follows:
      '<G=1*:[(0,1)]>' i.e., the generation one won't influence the analysis of symmetrical combination.

      The IDX lines identify the indices of the individuals that will be stored in the ped-sim generated VCF file:
      '<IDX=0:(1,1)>' the individual stored in the column 0 corresponds to the one in generation 1 and branch 1 of the
      DEF file.
      '<IDX=1:(1,2)>' the individual stored in the column 1 corresponds to the one in generation 1 and branch 2 of the
      DEF file.
      '<IDX=2:(2,1)>' the individual stored in the column 2 corresponds to the one in generation 2 and branch 1 of the
      DEF file.

      Notably, its general form is <IDX=n:(generation,branch)> where 'n' is the n-th column identifying the individual
      in the ped-sim generated VCF file (with 0 being the first individual) and the tuple (generation,branch)
      identifying the generation and branch of said individual in the DEF file.
      These associations are necessary for the script to be able to retrieve the sexes of each individual of interest
      from all possible combinations.

      The last part of the file is structured as a tabbed table:
      #IDX1	IDX2 RELATIONSHIP DEGREE
      0	2	Parent-Offspring	1
      1	2	Parent-Offspring	1

      '#IDX1	IDX2 RELATIONSHIP DEGREE': the first line representing its header.
      '0	2	Parent-Offspring	1' and
      '1	2	Parent-Offspring	1': first and second columns identify the individuals to be considered for the
      relationship specified in the third column. Fourth column defines the degree of said relationship.
      Thus, in this case we have two parent-offspring relationships between individuals 0 and 2 (first entry) as well as
      1 and 2 (second entry).
      Notably, the genders of those relationships vary for each combination and this script will list them in the
      logging file.

    • The logging file:
        - Four columns whose name are specified in the header:
            1) RELATIONSHIP: Name of the relationship of interest inclusive of the sexes of the individuals.
               Ex.: Half-siblings_F_F (two females half-siblings)
                    Half-siblings_M_F (male-female half-siblings)
                    Half-siblings_M_M (two males half-siblings)
           2) DEGREE: The degree of the relationships.
               Ex.: 2
           3) (COMBINATION,IDX1,IDX2):  A  list  of  triplets that allow  to identify the  individuals  (possessing the
              specified relationship)  within the generated VCF files.  Specifically, the  first integer identifies the
              combination number whereas second and third  indices identifies  the columns  within the VCF file of said
              individuals.

               Ex.: [(1, 0, 1), (1, 2, 3), (4, 0, 1), (4, 2, 3)], i.e.,

              (1, 0, 1): for the combination 1 (whose file name is determined by the REFERENCE column - e.g.,
              half-siblings_{}.vcf - and the combination number, thus, in the first case 'half-siblings_1.vcf'), the
              individuals identified by indices 0 (the first sample column of the VCF file) and 1 (the second sample
              column of the VCF file) are half-siblings.

              (1, 2, 3): for the combination 1 (whose file name is determined by the REFERENCE column - e.g.,
              half-siblings_{}.vcf - and the combination number, thus, in this case 'half-siblings_1.vcf'), the
              individuals identified by the indices 2 and 3 are half-siblings.

              (4, 0, 1): for the combination 4 (whose file name is determined by the REFERENCE column - e.g.,
              half-siblings_{}.vcf - and the combination number, thus, in this case 'half-siblings_4.vcf'), the
              individuals identified by the indices 0 and 1 are half-siblings.

              (4, 2, 3): for the combination 4 (whose file name is determined by the REFERENCE column - e.g.,
              half-siblings_{}.vcf - and the combination number, thus, in this case 'half-siblings_4.vcf'), the
              individuals identified by the indices 2 and 3 are half-siblings.

      4) REFERENCE: The general syntax to identify the files associated with each mentioned relationship.
         Ex.: half-siblings_{}.vcf, i.e., The individuals generated with the combination 1 are stored in
         half-siblings_1.vcf. In a more general way, the individuals generated with the combination N are stored in
         half-siblings_N.vcf (where N is an integer)
    :param str config: Configuration file
    :param int n: Number of samples
    :param str prefix: The founders files prefix
    :param str maf: The minor allele frequency file
    :param str gmap: The genetic map file
    :param int m_founders: The number of male founders to be created
    :param int f_founders: The number of female founders to be created
    :param str, optional x: The X chromosome identifier, default 'X'
    :param str, optional export: The script name to be created (default 'run_sim.sh')
    :param str, optional log_file: The logging file where the reference for all possible combinations of each
    relationship (i.e., pedigree samples) is is listed
    :param str, optional working_folder: Folder containing the DEF, IDX and MAP files (default '.')
    :param int, optional chr_idx: Column  index for chromosome  details for 'maf'  file with minor allele  frequency
    information (default 0)
    :param int, optional pos_idx: Column index for SNP position details  for 'maf' file  with minor allele frequency
    information (default 1)
    :param int, optional id_idx: Column index for ID details for 'maf' file with minor  allele frequency information
    (by default 2)
    :param int, optional ref_idx: Column index for reference base details for 'maf' file with minor allele frequency
    information (default 3)
    :param int, optional alt_idx: Column index for alternate base details for 'maf' file with minor allele frequency
    information (default 4)
    :param int, optional maf_idx: Column index for minor allele frequency details for 'maf' file (default 5)
    :param int, optional header: Number of header lines that will be skipped (default 0)
    Note: only for 'ref'  file containing minor  allele frequency values,  not considered for VCF files  (where  all
    headers info are copied to the output file)
    :param float, optional maf_threshold: The minor allele frequency threshold, i.e., all SNPs with MAF value smaller
    than 'maf_threshold' will be ignored (default is None, i.e., no MAF filtering)
    :param str, optional python: The command python to be used in the script (default 'python3')
    :param str, optional int_map: The interference map file, default '$PEDSIM_PATH/interfere/nu_p_campbell_X.tsv'"""

    print("\nCreating pedigree script.\nScript name: {}\n".format(export))
    if maf_threshold is None:
        maf_file = maf
    else:
        maf_file = "{}_maf.frq".format(prefix)
        mf.maf_filter(maf_file=maf, prefix="{}_maf".format(prefix), maf_threshold=maf_threshold, maf_idx=maf_idx)

    if working_folder is None:
        working_folder = "."

    script_line = "#!/bin/bash\n\n"
    out = open(export, "w")
    out.write(script_line)
    script_line = "for ((i=1;i <= {};i++))\ndo\n".format(n)  # loop for each simulation
    out.write(script_line)

    log = open(log_file, "w")
    log.write("#RELATIONSHIP\tDEGREE\t(COMBINATION,IDX1,IDX2)\tREFERENCE\n")

    script_line = " echo\n"
    out.write(script_line)
    script_line = " echo RUN $i of {}\n echo\n echo\n".format(n)  # create folder for the current run
    out.write(script_line)

    script_line = " mkdir run_$i\n"  # create folder for the current run
    out.write(script_line)

    # initialize the founders
    cmd = "{} $ADNA_PATH/rnd_pop.py".format(python)
    frq = "--ref {}".format(maf_file)
    pref = "--prefix ./run_$i/{}_$i".format(prefix)
    n_male = "--n_male {}".format(m_founders)
    n_female = "--n_female {}".format(f_founders)
    x_chr = "--x_chr {}".format(x)
    idx_chr = "--chr_idx {}".format(chr_idx)
    idx_pos = "--pos_idx {}".format(pos_idx)
    idx_id = "--id_idx {}".format(id_idx)
    idx_ref = "--ref_idx {}".format(ref_idx)
    idx_alt = "--alt_idx {}".format(alt_idx)
    idx_maf = "--maf_idx {}".format(maf_idx)
    idx_header = "--header {}".format(header)
    script_line = " {} {} {} {} {} {} {} {} {} {} {} {} {}\n".format(
        cmd, frq, pref, n_male, n_female, x_chr, idx_chr,
        idx_pos, idx_id, idx_ref, idx_alt, idx_maf, idx_header
    )
    out.write(script_line)
    cfg = open(config, "r")
    for cfg_line in cfg:
        if len(cfg_line.rstrip()) > 0 and not cfg_line.startswith("#"):
            print("Relationship files: {} (and .def)".format(os.path.join(working_folder, cfg_line.rstrip())))
            rel_dict = alib.parse_idx(idx_file=os.path.join(working_folder, cfg_line.rstrip()))
            n_cmb = rel_dict["n"]
            prefix_def = rel_dict["def"].replace("{}", "$j")
            script_line = " for ((j=1;j <= {};j++))\n do\n".format(n_cmb)  # loop for each simulation
            out.write(script_line)
            ped_cmd = "  $PEDSIM_PATH/ped-sim"
            ped_def = "-d {}".format(prefix_def)
            ped_map = "-m {}".format(gmap)
            ped_out = "-o ./run_$i/{}".format(os.path.basename(prefix_def).replace(".def", ""))
            ped_vcf = "-i ./run_$i/{}_$i.vcf".format(prefix)
            ped_x = "-X {}".format(x)
            ped_int = "--intf {}".format(int_map)
            ped_sex = "--sexes ./run_$i/{}_$i.fam".format(prefix)
            # ped_other = "--keep_phase --miss_rate 0"
            ped_other = "--keep_phase --founder_ids --fam --miss_rate 0"
            ped_cmd = "{} {} {} {} {} {} {} {} {}\n".format(ped_cmd, ped_def, ped_map, ped_out, ped_vcf,
                                                            ped_x, ped_int, ped_sex, ped_other)
            out.write(ped_cmd)
            line = " done\n"
            out.write(line)

            for c_idx, c_val in rel_dict.items():
                line = c_idx
                if line != "n" and line != "def":
                    line = line + "\t" + c_val[0] + "\t" + str(c_val[1]).replace("'", "") + "\t" +\
                           os.path.basename(rel_dict["def"]).replace(".def", ".vcf")
                    log.write(line + "\n")

    log.close()
    line = "done\n"
    out.write(line)
    cfg.close()
    out.close()
    print("Founders to be generated for a single ped-sim run (on all pedigrees):")
    print("   Female: {}".format(f_founders))
    print("     Male: {}".format(m_founders))
    print("\nNumbers of run: {}".format(n))


if __name__ == '__main__':
    fire.Fire(make)
