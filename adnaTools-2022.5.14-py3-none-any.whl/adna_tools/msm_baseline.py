import fire

__version__ = '2021.3.22'  # update also in msm_baseline doc


# noinspection PyUnboundLocalVariable
def msm_baseline(log_file: str, prefix: str, mode="median"):
    """MSM Baseline, aDNA Tools v.2021.3.22

    Given a LOG file pertaining to the mismatch coefficient (see dynamic_asc documentation for more details)
    compute the related baseline (according to the indicated mode) by considering all samples combinations
    stored into the LOG file. Thus, if you apply the dynamic_asc function over a VCF file containing unrelated
    individuals, the produced LOG file will have the window-averaged mismatch coefficient for all combination
    of samples. By passing that file to the msm_baseline one can estimate the baseline reference for each window.
    The mode parameter indicates how to compute this baseline. By default, the mode="median" will consider the
    median value within each window. Alternative implemented modes are "mean", which computes the average mismatch
    value, "max" the highest observed estimate, or "all" where multiple columns, one for each mode, are exported
    :param str log_file: Input file from which computing the dynamic allele sharing coefficient
    :param str prefix: Prefix for the output files (plot image and logging file)
    :param str, optional mode: The mode parameter indicates how to compute the baseline. By default, the mode="median"
    will consider the median value within each window. An alternative implemented mode is "mean" which computes the
    average mismatch value or "max" which considers the maximum value. Alternatively, by indicating "all", multiple
    columns each associated with the median, mean and maximum value will be created"""

    if not (mode == "all" or mode == "max" or mode == "mean" or mode == "median"):
        msg = "Unknown mode: {}. Available mode options are 'median', 'mean', 'max', or 'all'.".format(mode)
        raise ValueError(msg)

    log = open(log_file, "r")
    bas = open(prefix + ".bsl", "w")
    for line in log:
        if line.startswith("#"):
            if mode == "all":
                bas.write("#window_ID\tsample_size\tmedian\tmean\tmaximum\n")
            else:
                bas.write("#window ID\tsample size\t{}\n".format(mode))
        else:
            values = line.split("\t")
            bas_values = values[0:2]
            samples = [float(sample) for sample in values[2:]]
            n = len(samples)
            if mode == "median" or mode == "all":
                samples.sort()
                mid_n = n // 2
                if n % 2 == 0:
                    median = (samples[mid_n - 1] + samples[mid_n]) / 2
                else:
                    median = samples[mid_n]
                m = median
            if mode == "mean" or mode == "all":
                mean = 0
                for sample in samples:
                    mean = mean + sample
                mean = mean / n
                m = mean
            if mode == "max" or mode == "all":
                maximum = max(samples)
                m = maximum
            if mode == "all":
                m = [median, mean, maximum]
            if type(m) is list:
                for v in m:
                    bas_values.append(str(v))
            else:
                bas_values.append(str(m))
            bas_line = "\t".join(bas_values)
            bas_line = bas_line + "\n"
            bas.write(bas_line)
    log.close()
    bas.close()


if __name__ == '__main__':
    fire.Fire(msm_baseline)
