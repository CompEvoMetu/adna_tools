import fire

__version__ = '2021.3.22'  # update also in ancient_vcf doc


def append_vcf(txt_file: str, prefix: str):
    """Append VCF, aDNA Tools v.2021.3.2

    Given a text file containing a list of VCF files, it generates a new VCF file by appending each VCF following the
    order defined in the input file (one filename per line). No check on the consistency of the different VCF files is
    done, lines are read and written to the output file unchecked

    NOTE: Only the commented lines of the first VCF file are retained
    :param str txt_file: Text file containing the list of VCF files to be merged (appended) one after the other
    :param str prefix: Output filename"""

    print("\nMerging VCF files:")
    txt = open(txt_file, "r")
    out = open(prefix+".vcf", "w")
    first = True
    for filename in txt:
        print("   {}".format(filename.strip('\n')))
        vcf = open(filename.strip('\n'), "r")
        for line in vcf:
            if line.startswith("#"):
                if first:
                    out.write(line)
            else:
                if len(line.strip("\n")) > 0:
                    out.write(line)
        vcf.close()
        first = False
    txt.close()
    out.close()


if __name__ == '__main__':
    fire.Fire(append_vcf)
