import fire

__version__ = '2021.3.22'  # update also in rm doc


def rm(in_file: str, prefix: str):
    """Remove duplicate positions, aDNA Tools v.2021.3.22

    Remove duplicate positions (i.e., [chr, pos] considered as first and second columns)
    :param str, in_file: The input VCF or FRQ file
    :param str, prefix: Prefix string for the output VCF or FRQ file"""

    f = open(in_file, "r")
    lines_seen = set()  # encountered lines
    lines_dupl = set()  # duplicates
    for line in f:
        if not line.startswith("#"):
            vals = line.split()
            entry = (vals[0], vals[1])
            if entry not in lines_seen:
                lines_seen.add(entry)
            else:
                lines_dupl.add(entry)
    f.close()

    f = open(in_file, "r")
    if ".frq" in in_file.lower():
        w = open("{}.frq".format(prefix), "w")
    else:
        w = open("{}.vcf".format(prefix), "w")
    for line in f:
        if line.startswith("#"):
            w.write(line)
        else:
            vals = line.split()
            entry = (vals[0], vals[1])
            if entry not in lines_dupl:  # not a duplicate
                w.write(line)
            else:
                print("Removing position {} for chromosome {}".format(entry[1], entry[0]))
    w.close()


if __name__ == '__main__':
    fire.Fire(rm)
