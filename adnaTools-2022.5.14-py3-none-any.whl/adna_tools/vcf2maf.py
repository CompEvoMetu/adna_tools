import lib as a_lib
import fire

__version__ = '2021.3.22'  # update also in vcf2maf doc


# noinspection PyUnboundLocalVariable
def vcf2maf(vcf_file: str, maf_file: str, phased=None, switch_ref=False, alt=True, only_freq=False):
    """Compute MAF from VCF, aDNA Tools v.2021.3.22

    Given an input VCF file  ('vcf_file'), it computes minor allele frequencies for all SNPs and stores them in a given
    output file ('maf_file'). Unrecognized SNPs samples are store into a log file ('vcf_file'.log).
    Only entries '0' (+1 reference base), '1' (+1 alternate base), '0|0' (+2 reference base), '0|1' (+1 reference base,
    , +1 alternate base)  '1|0' (+1 reference base,  +1 alternate base) and '1|1'  (+2 alternate base)  are considered.
    If all SNPs in the VCF file have the aforementioned format, the log file will result empty. If the minor allele
    frequency is found to be > 0.5 then it automatically switches reference and alternate bases assigning the MAF as
    1-MAF. The switched SNPs will also be added to the log file in their original reference/alternate order. By default,
    alongside the MAF file it also retains in a separate file the alternate frequency values which can be used to
    generate random populations (alternate frequency file is named "alternate.frq")
    :param str, vcf_file: Input VCF file from which the minor allele frequencies are computed
    :param str, maf_file: Output file where the computed minor allele frequencies are stored
    :param bool, optional phased: If set, it assumes the data to be phased. Default behavior determined automatically
    , i.e., phased=None
    :param bool, optional switch_ref: Flag that allows to switch reference and alternate bases if its MAF is actually
    bigger than 0.5 (default False)
    :param bool, alt: Stored also the alternate frequency values (default True)
    :param bool, only_freq: If set, the output files will only contain the frequency values. By default, also other
    information are stored"""

    if phased is None:
        print("\nDefine data type by looking at the first sample:")
        file_in = open(vcf_file, "r")
        for line in file_in:
            if not line.startswith("#"):
                values = line.split("\t")
                if "|" in values[9]:
                    div_snp = "|"
                    msg = "   The VCF file has phased samples"
                elif "/" in values[9]:
                    div_snp = "/"
                    msg = "   The VCF file has unphased samples"
                else:
                    file_in.close()
                    msg = "Couldn't determine if the input VCF file contains phased or unphased data. Please set the " \
                          "'phased' flag accordingly. "
                    raise TypeError(msg)
                file_in.close()
                break
        print(msg)
    elif phased:
        div_snp = "|"
    else:
        div_snp = "/"

    out_log = "{}.log".format(vcf_file)  # log file to store non-considered SNPs

    txt = "disabled"
    if switch_ref:
        txt = "enabled"

    print("Switch reference base if MAF > 0.5: {}".format(txt))
    print("Computing MAFs from '{}'...".format(vcf_file))

    # open files for reading/writing
    in_file = open(vcf_file, "r")
    out_file = open(maf_file, "w")
    if alt:  # store the alternate frequency values
        alt_file = open("alternate.frq", "w")
    log_file = open(out_log, "w")

    # read line by line
    i = 0
    for line in in_file:
        i += 1
        if line.startswith("#"):  # ignore comment line
            continue

        # extract values of interest
        line_split = line.split()
        chrm = line_split[0]
        pos = line_split[1]
        chr_id = line_split[2]
        ref = line_split[3]
        alt = line_split[4]
        gt = line_split[9:]

        # counters for reference and alternate bases
        ref_count = 0
        alt_count = 0

        for element in gt:  # examine the samples for the current SNP

            # update the frequency counters accordingly
            # g_type = element.split(":")[0]
            g_type = a_lib.clean_snp(element, div_snp=div_snp)
            if g_type[0] == ".":
                if g_type[2] == "0":
                    ref_count += 1
                elif g_type[2] == "1":
                    alt_count += 1
            elif g_type[2] == ".":
                if g_type[1] == "0":
                    ref_count += 1
                elif g_type[1] == "1":
                    alt_count += 1
            elif g_type == "0|0":
                ref_count += 2
            elif g_type == "0|1" or g_type == "1|0":
                ref_count += 1
                alt_count += 1
            elif g_type == "1|1":
                alt_count += 2
            elif g_type == "0":
                ref_count += 1
            elif g_type == "1":
                alt_count += 1
            else:  # log specifics for ignored SNPs
                info = "g_type={}\n".format(g_type)
                log_file.write(info)

        # compute minor allele frequency for the current SNP
        if not alt_count + ref_count == 0:
            alt_freq = alt_count / float(alt_count + ref_count)
            alt_freq = round(alt_freq, 3)

            if switch_ref and alt_freq > 0.5:  # switch reference and alternate bases and update the frequency value
                old_ref = ref
                old_alt = alt

                # store the switch in the log with the original configuration
                info = "switched=({}, {}, {}, {}, {}, {})\n".format(chrm, pos, chr_id, old_ref, old_alt, alt_freq)
                log_file.write(info)

                alt = ref
                ref = old_alt
                alt_freq = 1 - alt_freq

            # update the maf value if required
            maf = alt_freq
            if maf > 0.5:
                maf = 1 - maf

            # write result on the output file
            if only_freq:
                output = str(maf)
            else:
                output = "\t".join([chrm, pos, chr_id, ref, alt, str(maf)])
            output = output + "\n"
            out_file.write(output)

            if alt:
                if only_freq:
                    output = str(alt_freq)
                else:
                    output = "\t".join([chrm, pos, chr_id, ref, alt, str(alt_freq)])
                output = output + "\n"
                alt_file.write(output)

    # close the files
    in_file.close()
    out_file.close()
    log_file.close()
    if alt:
        alt_file.close()


if __name__ == '__main__':
    fire.Fire(vcf2maf)
