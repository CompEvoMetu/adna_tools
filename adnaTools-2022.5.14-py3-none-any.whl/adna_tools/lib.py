"""
Ancient DNA tools - Library.
"""
from numpy.random import default_rng
from termcolor import colored
from datetime import date
from random import choice
from pathlib import Path
import itertools as it
import numpy as np
import warnings
import logging
import shutil
import math
import sys
import ast
import re
import os

__version__ = '2021.3.22'


def clean_snp(snp: str, div_snp="|") -> str:
    """
    Fix the format of the given SNP to the expected syntax. Remove unused information following the suffix ":" and
    replace the separator if necessary (to the standard considered within the code, i.e., "|"). This "cleaning" step
    has been added to be sure the input SNPs are conformed to the expected syntax, i.e., "0", "1", "0|0", "0|1", "1|0",
    or "1|1" (thus, be always careful to consider the type of VCF file you are using)
    :param str snp: The SNP to be checked
    :param str, optional div_snp: The expected separator
    :return: The cleaned SNP according to the expected syntax"""

    if div_snp == "|":
        alt_snp = "/"
    else:
        alt_snp = "|"

    if len(snp) > 1:
        if (div_snp not in snp) and (alt_snp not in snp):  # assumes single value with additional info, e.g., "1:blah"
            values = snp.split(":")
            c_snp = values[0]
        else:
            if div_snp not in snp:
                div_snp = alt_snp

            values = snp.split(":")
            values = values[0].split(div_snp)
            c_snp = "{}|{}".format(values[0], values[1])
    else:
        c_snp = snp

    return c_snp


def match_snp(snp: str, div_snp="|") -> int:
    """
    Convert the diallelic or haploidized SNP, with the genotype coding system of 0, 1, 2.
    Recognized values are the following: 0|0, 0|1, 1|0, 0|0 or 0 and 1 (converted respectively to 0|0 and 1|1).
    The separator could either be "|", i.e., phased, or "/", i.e., non-phased
    :param str snp: The SNP to be converted
    :param str, optional div_snp: Standard SNP divider (default, phased "|")
    :return: int: The genotype as coding system of 0, 1, 2"""

    # match the SNP value with its code
    if snp == "0" or snp == "1":
        code = match_snp("{0}{1}{0}".format(snp, div_snp), div_snp)
    elif snp == "0{}0".format(div_snp):
        code = 0
    elif snp == "1{}1".format(div_snp):
        code = 2
    else:
        code = 1

    return code


def update_asc(asc: list, ind_values: list, maf) -> list:
    """
    Update the list of (partial, non-averaged sums) allele sharing coefficient estimates given a list of SNPs (one per
    individual) and the minor allele frequency value associated with the considered SNP position
    :param list asc: List of (partial, non-averaged sums) allele sharing coefficient estimates
    :param [str] ind_values: List of SNPs, one per individual
    :param float maf: minor allele frequency value associated with the considered SNP position
    :return: list: updated sum for the computation of the allele sharing coefficients"""

    upd_asc = asc.copy()
    f = float(maf)

    codes = []
    for v in ind_values:
        codes.append(match_snp(clean_snp(v)))
    n = len(codes)
    idx = 0
    for idx_1 in range(n - 1):
        for idx_2 in range(idx_1 + 1, n):
            coeff_1 = (codes[idx_1] - 2 * f) / math.sqrt(2 * f * (1 - f))
            coeff_2 = (codes[idx_2] - 2 * f) / math.sqrt(2 * f * (1 - f))
            upd_asc[idx] = upd_asc[idx] + (coeff_1 * coeff_2)
            idx = idx + 1

    return upd_asc


def update_msm(msm: list, ind_values: list, phased=False) -> list:
    """
    Update the list of (partial, non-averaged sums) mismatch coefficient estimates given a list of SNPs (one per
    individual) and the minor allele frequency value associated with the considered SNP position
    :param list msm: List of (partial, non-averaged sums) mismatch coefficient estimates
    :param [str] ind_values: List of SNPs, one per individual
    :param bool, optional phased: If set it assumes the data to be phased. Default behavior unphased (affects only the
    mismatch coefficient)
    :return: list: updated sum for the computation of the mismatch coefficients"""

    if phased:
        div_snp = "|"
    else:
        div_snp = "/"

    upd_msm = msm.copy()
    codes = []
    for v in ind_values:
        c_v = clean_snp(v, div_snp)
        if c_v == "0" or c_v == "1":
            codes.append([c_v, c_v])
        elif len(c_v) == 3 and c_v[1] == "|":
            codes.append([c_v[0], c_v[2]])
        else:
            msg = "Unrecognized SNP entry: {} (clean version is '{}')".format(v, c_v)
            raise ValueError(msg)

    n = len(codes)
    if phased:  # phased data consider also their position
        idx = 0
        for idx_1 in range(n - 1):
            for idx_2 in range(idx_1 + 1, n):
                if not codes[idx_1][0] == codes[idx_2][0]:
                    upd_msm[idx] += 1
                if not codes[idx_1][1] == codes[idx_2][1]:
                    upd_msm[idx] += 1
                idx = idx + 1
    else:  # randomly pick one of the two values from each considered sample
        idx = 0
        for idx_1 in range(n - 1):
            for idx_2 in range(idx_1 + 1, n):
                ch_1 = choice(codes[idx_1])
                ch_2 = choice(codes[idx_2])
                if not ch_1 == ch_2:
                    upd_msm[idx] += 2  # +2 simply because at the final stage we divine by 2*N (as for phased data)
                idx = idx + 1

    return upd_msm


def split_string(txt: str, length: int) -> [str]:
    """
    Distribute a given text string over multiple lines considering the specified line length
    :param str txt: The text to split
    :param int length: The length of the line
    :return: [str]: The list containing the text divided over multiple lines (if necessary)"""

    new_txt = [txt]
    if len(new_txt[0]) > length:
        tmp = txt.split()
        words = []
        for word in tmp:
            if len(word) <= length:
                words.append(word)
            else:
                w_start = 0
                w_end = length - 3
                words.append("{}...".format(word[w_start:w_end]))
                while len(word[w_end:]) > length - 3:
                    w_start = w_end
                    w_end = w_start + length - 6
                    words.append("...{}...".format(word[w_start:w_end]))
                words.append("...{}".format(word[w_end:]))
        idx = 1
        new_txt = []
        new_line = words[0]
        while idx < len(words):
            if len(new_line + " " + words[idx]) <= length:
                new_line = new_line + " " + words[idx]
            else:
                new_txt.append(new_line)
                new_line = words[idx]
            idx = idx + 1
        if len(new_line) > 0:
            new_txt.append(new_line)

    return new_txt


def print_msg(msg_type="", msg_prefix="", msg="", msg_suffix="",
              type_width=15, prefix_width=40, msg_width=50, suffix_width=35,
              feedback=True, separator_top=False, separator_bottom=False, separator="═", multiple_line=True,
              color=None, on_color=None, type_color="green", logging_file=None, progress_bar=None, colors=False):
    """
    Print messages with proper formatting and optionally a progress bar.

    :param str, optional msg_type: The string identifying the message type will be shown within the first column
    with green color (by default, it can be changed via 'type_color') and in square brackets
    :param str, optional msg_prefix: A prefix string which will be shown in the second column with grey color
    and anticipate the most relevant part of the message (msg)
    :param str, optional msg: The main content of the message will be shown in the third column in black color
    and bold
    :param str, optional msg_suffix: A suffix string which contains additional relevant information
    which will be shown in the fourth column with grey color
    :param int, optional type_width: Width of the first column (default 15)
    :param int, optional prefix_width: Width of the second column (default 40)
    :param int, optional msg_width: Width of the third column (default 50)
    :param int, optional suffix_width: Width of the fourth column (default 35)
    :param bool, optional feedback: Flag to enable/disable the printout (default True)
    :param bool, optional separator_top: Flag to enable/disable the printing of the separator line prior the printout
    (default False)
    :param bool, optional separator_bottom: Flag to enable/disable the printing of the separator line following (default
    False)
    :param str, optional separator: Character/string used as separator template (default "=")
    :param bool, optional multiple_line: Flag that enables printout over multiple lines when necessary (default True)
    :param str, optional color: Text color of the main message (msg). Default value is None, i.e. the standard output
    color (depending on system)
    :param str, optional on_color: Highlight color for the main message ('msg'). Default no background color (None).
    Possible values: "on_grey", "on_red", "on_green", "on_yellow", "on_blue", "on_magenta", "on_cyan" and "on_white"
    :param str, optional color: Text color of the main message (msg). Default value is None, i.e. the standard output
    color (depending on system)
    :param str, optional type_color: Text color of the type message ('type_msg'). Default value is "green"
    :param optional logging_file: Record the printed text also on a logging file (default None)
    :param progress_bar: Information to update a progress bar. Specifically, a list of values:
    [current position, maximum/latest position, length in character of the bar]
    :param bool, optional colors: Enable the usage of colors (default False)"""

    tot_length = type_width + prefix_width + msg_width + suffix_width
    if separator == "\n":
        separator_line = ""
    else:
        separator_line = separator * tot_length
    if separator_top:
        msg_sep = "{}".format(separator_line)
        if feedback and progress_bar is None:
            print(msg_sep)
        if logging_file is not None and progress_bar is None:
            msg_sep = "{}\n".format(msg_sep)
            logging_file.write(msg_sep)

    if multiple_line and (len(msg_type) > type_width - 2 or len(msg_prefix) > prefix_width - 2 or
                          len(msg) > msg_width - 2 or len(msg_suffix) > suffix_width - 2):
        msg_type = split_string(msg_type, type_width - 2)
        msg_prefix = split_string(msg_prefix, prefix_width - 2)
        msg = split_string(msg, msg_width - 2)
        msg_suffix = split_string(msg_suffix, suffix_width - 2)
        n_lines = max(len(msg_type), len(msg_prefix), len(msg), len(msg_suffix))
        idx_line = 0
        while idx_line < n_lines:
            line_type = ""
            line_prefix = ""
            line_msg = ""
            line_suffix = ""
            if idx_line < len(msg_type):
                line_type = msg_type[idx_line]
            if idx_line < len(msg_prefix):
                line_prefix = msg_prefix[idx_line]
            if idx_line < len(msg):
                line_msg = msg[idx_line]
            if idx_line < len(msg_suffix):
                line_suffix = msg_suffix[idx_line]
            print_msg(msg_type=line_type, msg_prefix=line_prefix, msg=line_msg, msg_suffix=line_suffix,
                      type_width=type_width, prefix_width=prefix_width, msg_width=msg_width,
                      suffix_width=suffix_width, feedback=feedback, type_color=type_color,
                      logging_file=logging_file, progress_bar=progress_bar)
            idx_line = idx_line + 1
    else:
        # crop the type message if necessary and apply formatting by justifying to the right
        if len(msg_type) > type_width - 2:
            mid = (type_width - 5) // 3
            rem = type_width - 5 - mid
            type_txt = "[{}...{}]".format(msg_type[0: mid], msg_type[-rem:])
        elif len(msg_type) == 0:
            type_txt = ""
        else:
            type_txt = "[{}]".format(msg_type)
        type_log = type_txt.rjust(type_width)
        if colors:
            type_txt = colored(type_log, type_color)
        else:
            type_txt = type_log

        # crop the prefix message if necessary and apply formatting by justifying to the right
        if len(msg_prefix) > prefix_width:
            mid = (prefix_width - 3) // 3
            rem = prefix_width - 3 - mid
            prefix_txt = "{}...{}".format(msg_prefix[0: mid], msg_prefix[-rem:])
        else:
            prefix_txt = msg_prefix
        prefix_log = prefix_txt.rjust(prefix_width)
        if colors:
            prefix_txt = colored(prefix_log, "grey")
        else:
            prefix_txt = prefix_log

        # crop the message if necessary and apply formatting by justifying to the right
        if len(msg) > msg_width:
            mid = (msg_width - 3) // 3
            rem = msg_width - 3 - mid
            msg_txt = "{}...{}".format(msg[0: mid], msg[-rem:])
        else:
            msg_txt = msg
        msg_log = msg_txt.rjust(msg_width)
        if colors:
            msg_txt = colored(msg_log, color=color, on_color=on_color, attrs=["bold"])
        else:
            msg_txt = msg_log

        # crop the suffix message if necessary and apply formatting by justifying to the right
        if len(msg_suffix) > suffix_width - 1:
            mid = (suffix_width - 4) // 3
            rem = suffix_width - 4 - mid
            suffix_txt = "{}...{}".format(msg_suffix[0: mid], msg_suffix[-rem:])
        else:
            suffix_txt = " {}".format(msg_suffix)
        suffix_log = suffix_txt.ljust(suffix_width)
        if colors:
            suffix_txt = colored(suffix_log, "grey")
        else:
            suffix_txt = suffix_log

        msg_log = "{}{}{}{}\n".format(type_log, prefix_log, msg_log, suffix_log)
        msg_txt = "{}{}{}{}".format(type_txt, prefix_txt, msg_txt, suffix_txt)
        if feedback:
            if progress_bar is not None:
                print_progress_bar(progress_bar[0], progress_bar[1], size=progress_bar[2], prefix=type_txt + prefix_txt,
                                   txt=suffix_txt)
            else:
                print(msg_txt)
        if logging_file is not None:
            logging_file.write(msg_log)

    if separator_bottom:
        msg_sep = "{}".format(separator_line)
        if feedback and progress_bar is None:
            print(msg_sep)
        if logging_file is not None and progress_bar is None:
            msg_sep = "{}\n".format(msg_sep)
            logging_file.write(msg_sep)


def print_progress_bar(n, max_n, txt="", prefix="", size=10):
    """
    Print a progress bar
    :param Number n: Current position
    :param Number max_n: Maximum value for position
    :param str, optional txt: Additional text to print (on the right side). By default none, i.e., empty string
    :param str, optional prefix: Additional text to print prior to the progress bar (on the left side). By default none,
    i.e., empty string
    :param int, optional size: Size in characters of the progress bar (default 10)"""

    prg = n / max_n
    sys.stdout.write('\r')
    sys.stdout.write(prefix + f"[{'=' * int(size * prg):{size}s}] {int(100 * prg)}%  {txt}")
    sys.stdout.flush()


def extract_freq(info: str, tag: str) -> float:
    """
    Given a string containing a series of tag, it extracts the frequency tag returning its floating value
    :param str info: The string containing one or more tags (each separated by ';')
    :param str tag: The TAG that defines the frequency value
    :return: float: The frequency value found in the info string"""

    idx = info.find(tag)
    val = float(-1)
    if not idx == -1:  # if TAG not present idx is -1
        start = idx + len(tag) + 1
        end = info[start:].find(";")

        # Extract the relevant string for the value
        if end == -1:
            val = info[start:]
        else:
            val = info[start: start + end]

        if "," in val:
            print("Possible multiple assignment for 'AFngsrelate': {}. Selecting the first value.".format(val))
            val = val.split(",")[0]

        try:
            val = float(val)  # convert the string to number
        except ValueError:
            msg = "Unrecognized freq. value: {}Assigning -1.".format(val)
            raise ValueError(msg)

    return val


def rnd_snp(chromosome, x_chromosome, n, n_female, n_male, maf, invert_maf: bool, rng, log, skip_x=False) -> list:
    """
    Randomize the SNPs for the given individuals and consider both autosomes and x chromosome cases.
    NOTE: the "maf" parameter refers to the alternate allele frequency value and not to the minor allele frequency
    value
    :param chromosome: Current chromosome
    :param x_chromosome: Identifier associated with the X chromosome
    :param n: Number of SNPs to be randomly generated
    :param n_female: Number of SNPs to be randomly generated for female individuals
    :param n_male: Number of SNPs to be randomly generated for male individuals
    :param maf: Alternate allele frequency value for the current SNP position
    :param invert_maf: Flag that allows to invert the MAF value, i.e., considers 1-maf
    :param rng: Random number generator
    :param log: Logging file
    :param skip_x: Flag to indicate if it is necessary to skip the random generation of X chromosome SNPs
    :return: The randomly generated SNPs (empty list in case no randomization was performed)"""

    n = int(n)
    maf = float(maf)
    if invert_maf:
        maf = 1 - maf

    # Assign (1-maf) probability to select the reference base (i.e., 0) and
    # (maf) probability to select the alternate base (i.e., 1)
    if not str(chromosome) == str(x_chromosome):  # autosomes
        strand_1 = rng.choice(a=["0", "1"], size=n, p=[1 - maf, maf])
        strand_2 = rng.choice(a=["0", "1"], size=n, p=[1 - maf, maf])
        values = ["{}|{}".format(x, y) for x, y in zip(strand_1, strand_2)]
    else:  # x chromosome
        if not skip_x and n_female is not None and n_male is not None:
            strand_1 = rng.choice(a=["0", "1"], size=n, p=[1 - maf, maf])  # for both males and females
            strand_2 = rng.choice(a=["0", "1"], size=n_female, p=[1 - maf, maf])  # for females
            # m_values = ["{}|{}".format(x, x) for x in strand_1[n_female:]]  # assemble X chromosome for males
            m_values = ["{}".format(x) for x in strand_1[n_female:]]  # assemble X chromosome for males
            f_values = ["{}|{}".format(x, y) for x, y in
                        zip(strand_1[0: n_female], strand_2)]  # assemble X chromosome for females
            values = f_values + m_values  # merge all the values prior to re-assemble the line
        else:
            if not skip_x:
                print_msg()  # empty line for visual feedback
                print_msg(msg_type="Warning", msg_prefix="'n_female'/'n_male' not set",
                          msg="Ignoring the X chromosome SNPs",
                          msg_suffix="(see help for more details)", type_color="yellow", separator_top=True,
                          separator="\n", logging_file=log)
                print_msg()  # empty line for visual feedback
            values = []

    return values


def snp_list(file: str, chr_idx=0, pos_idx=1, val_idx=None, header='#', x_chr=23) -> [list, dict]:
    """
    Given a VCF (or genetic map) file, returns a list of its chromosomes and positions
    :param str file: Input VCF file
    :param int, optional chr_idx: Index identifying the column for the chromosome value (default 0)
    :param int, optional pos_idx: Index identifying the column for the position value (default 1)
    :param int, optional val_idx: Index identifying the column for a (floating) value of interest (default None)
    :param str, optional header: Header type, e.g., '#' implies all lines starting with #,
    1 implies the first line; 5 implies the first five lines, ...
    :param str or int, optional x_chr: The ID associated with the X chromosome (default is 23)
    :return: [list, dict]: Chromosomes and their positions in list and dictionary format"""

    file_in = open(file, "r")
    snps_map = []
    snps_dict = {}
    snp = ""
    pos = []
    skip_line = 0
    for line in file_in:
        if type(header) is int and skip_line < header:
            # skip the line
            skip_line = skip_line + 1
        else:
            if type(header) is int or (type(header) is not int and not line.startswith(header)):  # not a comment
                # select the chromosome and position of the current line
                values = line.split()
                line_chromosome = values[chr_idx]
                line_position = values[pos_idx]
                line_snp = line_chromosome.replace("chr", "")
                line_snp = line_snp.replace("X", str(x_chr))
                if not snp == line_snp:
                    if not snp == "":
                        snps_dict[snp] = pos
                        pos = []
                    snp = line_snp
                if val_idx is not None:
                    line_value = values[val_idx]
                    pos.append((line_position, line_value))
                    line_chromosome = line_snp
                    try:
                        snps_map.append((int(line_chromosome), int(line_position), float(line_value)))
                    except ValueError:
                        snps_map.append((line_chromosome, int(line_position), float(line_value)))
                else:
                    pos.append(line_position)
                    try:
                        snps_map.append((int(line_chromosome), int(line_position)))
                    except ValueError:
                        snps_map.append((line_chromosome, int(line_position)))
    file_in.close()
    snps_dict[snp] = pos

    return snps_map, snps_dict


def interpolation_test(map_file: str, f_maps: str, m_maps: str, x_chr: str, idxs=None):
    """
    Additional test called during debug to identify possible problems to check
    :param str map_file: The generated map file
    :param str f_maps: The reference female genetic maps
    :param str m_maps: The reference male genetic maps
    :param str x_chr: The X chromosome ID
    :param [int] idxs: Indices to identify the columns of interest of the reference genetic maps"""

    if idxs is None:
        idxs = [0, 1, 3]
    m_cm = None
    f_cm = None
    eof = None
    m_pos = None
    f_pos = None
    m_line = None
    prev_m_pos = None
    prev_f_pos = None
    prev_m_cm = None
    prev_f_cm = None

    map_in = open(map_file, "r")  # map to be checked

    curr_chr = -1  # chromosome reference
    m_in = None  # male genetic map for the current chromosome
    f_in = None  # female genetic map for the current chromosome
    header = True  # to skip the first line as it is a header

    for line in map_in:  # read all the lines in the map file to be checked
        if header:  # first line is a header, skip it
            header = False
        else:

            # values of interest from the file to be checked
            values = line.split()
            line_chr = values[0]
            line_pos = values[1]
            line_m_cm = values[2]
            line_f_cm = values[3]
            if not line_chr == curr_chr:  # chromosome is different, switch to new chromosome files

                # close previously opened files (if necessary)
                if m_in is not None:
                    m_in.close()
                if f_in is not None:
                    f_in.close()

                # open files for the new chromosome
                if not line_chr == x_chr:
                    m_in = open(m_maps.format(line_chr))
                    _ = m_in.readline()  # first line is a header
                f_in = open(f_maps.format(line_chr))
                _ = f_in.readline()  # first line is a header
                curr_chr = line_chr
                m_pos = None  # current reference position for male column
                m_cm = None  # current reference cM for male column
                f_pos = None  # current reference position for female column
                f_cm = None  # current reference cM for female column
                prev_m_pos = None  # previous reference position for male column
                prev_m_cm = None  # previous reference cM for male column
                prev_f_pos = None  # previous reference position for female column
                prev_f_cm = None  # previous reference cM for female column
                eof = False  # flag to indicate when the end of file is reached (for the reference map files)

            # read current reference position and cM values for both male and female
            keep_reading = True
            while keep_reading:
                if eof:
                    keep_reading = False
                elif m_pos is not None and int(m_pos) >= int(line_pos):
                    keep_reading = False
                else:
                    if not line_chr == x_chr:
                        m_line = m_in.readline()
                    f_line = f_in.readline()

                    if len(f_line) == 0:
                        keep_reading = False
                        eof = True
                    else:
                        f_values = f_line.split()
                        if f_pos is not None:
                            prev_f_pos = f_pos
                            prev_f_cm = f_cm
                        f_pos = f_values[idxs[1]]
                        f_cm = float(f_values[idxs[2]])

                        if not line_chr == x_chr:
                            m_values = m_line.split()
                            if m_pos is not None:
                                prev_m_pos = m_pos
                                prev_m_cm = m_cm
                            m_pos = m_values[idxs[1]]
                            m_cm = float(m_values[idxs[2]])
                        else:
                            prev_m_pos = prev_f_pos
                            prev_m_cm = 0
                            m_pos = f_pos
                            m_cm = 0

                        if int(m_pos) >= int(line_pos):
                            keep_reading = False
            # same position, so no interpolation, it should have just the same values
            line_m_cm = float(line_m_cm)
            line_f_cm = float(line_f_cm)
            if int(line_pos) == int(m_pos):
                if not line_m_cm == m_cm:  # error
                    msg = "Inconsistent male genetic map, chr {} at pos {}: found {}, expected {}.".format(
                        line_chr,
                        line_pos,
                        line_m_cm,
                        m_cm)
                    raise ValueError(msg)
                if not line_f_cm == f_cm:  # error
                    msg = "Inconsistent female genetic map, chr {} at pos {}: found {}, expected {}.".format(
                        line_chr,
                        line_pos,
                        line_f_cm,
                        f_cm)
                    raise ValueError(msg)
            else:
                if int(line_pos) < int(m_pos):  # line_pos < m_pos
                    if prev_m_pos is not None:
                        coeff = (float(line_pos) - float(prev_m_pos)) / (float(m_pos) - float(prev_m_pos))
                        check_m_cm = prev_m_cm + coeff * (m_cm - prev_m_cm)
                        check_f_cm = prev_f_cm + coeff * (f_cm - prev_f_cm)
                    else:
                        check_m_cm = m_cm
                        check_f_cm = f_cm
                else:
                    check_m_cm = m_cm
                    check_f_cm = f_cm

                if not check_m_cm == float(line_m_cm):
                    msg = "Inconsistent male genetic map, chr {} at pos {}: found {}, expected {}.".format(
                        line_chr,
                        line_pos,
                        line_m_cm,
                        check_m_cm)
                    raise ValueError(msg)
                if not check_f_cm == float(line_f_cm):
                    msg = "Inconsistent female genetic map, chr {} at pos {}: found {}, expected {}.".format(
                        line_chr,
                        line_pos,
                        line_f_cm,
                        check_f_cm)
                    raise ValueError(msg)
    if m_in is not None:
        m_in.close()
    f_in.close()


# noinspection PyUnboundLocalVariable,PyTypeChecker
def rnd_pop(ref: str, prefix: str, n=None, n_female=None, n_male=None,
            maf_ref=None, invert_maf=False, tag="AFngsrelate", x_chr="X",
            ind_prefix="ind", seed=None, chr_idx=0, pos_idx=1,
            id_idx=None, ref_idx=2, alt_idx=3, maf_idx=4, header=0):
    """
    Generate a random population given a reference  VCF  file  (inclusive of allele frequencies tagged associated to the
    probability of the alternate value) or given an alternate value frequency file. By setting either n or  both
    n_female and n_male you specify the size of the population. If sexes should be assigned,  they are also  appended to
    the individuals' ID  (as well  as being stored into an external file where each  row, one per individual,  is
    defined by [individual ID] [F/M]). According to the given parameters,  a logging  file,  VCF  file, and allele
    sharing coefficient  file are created.  The allele sharing coefficient  file  keeps track  of  the  relatedness
    among the created individuals. Within the logging file the settings  used for  the random generation  of the
    population are stored  (e.g.,  the seed number for the random number  generator). Within the created   VCF file,
    the minor  allele frequency values (NOTE: the MAF, not the alternate value frequency) are also stored with the
    specified tag.

    Output(s), varying in accordance with the given parameters:
    • VCF file with the randomized individuals
    • ASC file with the allele sharing coefficient estimates between all individuals
    • LOG file with the feedback on the randomization process
    • FAM file with the sexes of the generated individuals

    Examples (ADNA_PATH="/mnt/.../python/packages/adna_tools/"; export ADNA_PATH):

    • Documentation:
        python $ADNA_PATH/rnd_pop.py --help

    • Generate random individuals with both autosomes and X chromosome and sexes given a MAF file:
        python $ADNA_PATH/rnd_pop.py --ref maf.frq --prefix rnd_pops --n_male 3 --n_female 2 --x_chr X

        Note: The parameter x_chr could be omitted as the default value identifying X chromosome SNPs is 'X'.

    • Generate random individuals with autosomes (ignoring X chromosome as no sex specifications are given) with MAF
     file as input:
        python $ADNA_PATH/rnd_pop.py --ref maf.frq --prefix rnd_pops --n 10

    • Generate random individuals with both autosomes and X chromosome and sexes given a VCF file with MAF specified
     with a tag (within the VCF file):
        python $ADNA_PATH/rnd_pop.py --ref reference.vcf --maf_ref tag --prefix rnd_pops
        --n_male 3 --n_female 2 --x_chr 23

    • Generate random  individuals with autosomes  (ignoring X chromosome as no sex specifications are given) with a
    VCF file and MAF defined via tag (within the VCF file):
        python $ADNA_PATH/rnd_pop.py --ref reference_auto.vcf --maf_ref tag --prefix rnd_pops --n 10 --x_chr 23

        Note: The parameter x_chr is specified as the  VCF file contains also X chromosome data,  when found,  since
        the sexes  are not required,  it will be ignored.  If the  VCF file does not contain  X chromosome data then
        there is no need to specify this parameter.

    • Generate random individuals with autosomes and sexes with a  VCF file and MAF defined via tag  (within the VCF
    file):
        python $ADNA_PATH/rnd_pop.py --ref reference_auto.vcf --maf_ref tag --prefix rnd_pops
        --n_female 5 --n_male 9

    • Generate  random individuals with autosomes,  with no sex specified, given a  VCF file and MAF defined via tag
    (within the VCF file):
        python $ADNA_PATH/rnd_pop.py --ref reference_auto.vcf --maf_ref tag --prefix rnd_pops --n 10

    • Generate random individuals with X chromosome and sexes given a  VCF file and MAF defined via tag  (within the
    VCF file):
        python $ADNA_PATH/rnd_pop.py --ref reference_x.vcf --maf_ref tag --prefix rnd_pops
        --n_female 5 --n_male 9 --x_chr 23
    :param str ref: Reference VCF or minor allele frequency file
    :param str prefix: Prefix for output file(s)
    :param int, optional n: Number of individuals to be created (default None)
    :param int, optional n_female: Number of female individuals to be created (default None)
    :param int, optional n_male: Number of male individuals to be created (default None)
    :param optional maf_ref: Reference for minor allele frequency values:

    • None: default option, the ref file is assumed  to contain MAF info and need to specify column indices for CHR
    (chr_idx), POS (pos_idx), ID (id_idx, optional,  not considered by default),  REF (reference base, ref_idx), ALT
    (alternate base, alt_idx), MAF (minor allele frequency, maf_idx)

    • 'tag': consider the specified tag ('tag' option,  by default 'AFngsrelate') in the 'ref' file which is assumed
    to be a VCF file

    • 'rnd': random choice, 0.5 for all SNPs and the 'ref' file is assumed to be a VCF file
    :param bool, optional invert_maf: Consider (1-maf) (default False)
    :param str, optional tag: If MAFs are stored  within  the reference  VCF file,  consider the given TAG  (default
    'AFngsrelate')
    :param optional x_chr: Label associated with the X chromosome (default 'X')
    :param optional ind_prefix: Prefix for naming of individuals (default 'ind')
    :param optional seed: Seed for random number generator (default None)
    :param int, optional chr_idx: Column  index for chromosome  details for 'ref'  file with minor allele  frequency
    information (default 0)
    :param int, optional pos_idx: Column index for SNP position details  for 'ref' file  with minor allele frequency
    information (default 1)
    :param int, optional id_idx: Column index for ID details for 'ref' file with minor  allele frequency information
    (by default None, i.e., not considered)
    :param int, optional ref_idx: Column index for reference base details for 'ref' file with minor allele frequency
    information (default 2)
    :param int, optional alt_idx: Column index for alternate base details for 'ref' file with minor allele frequency
    information (default 3)
    :param int, optional maf_idx: Column index for minor allele frequency details for 'ref' file (default 4)
    :param int, optional header: Number of header lines that will be skipped (default 0)
    Note: only for 'ref'  file containing minor  allele frequency values,  not considered for VCF files  (where  all
    headers info are copied to the output file)"""

    # init variables
    fam = None
    maf = None

    end_task = False  # flag to end the task in case of wrong parameters
    skip_x = False  # flag to handle potential settings problem with the X chromosome

    # determine the approach to generate synthetic individuals (and feedback)
    if maf_ref is not None:  # expect ref to be a VCF file and use the tag (or random) to read the MAFs
        if maf_ref.lower() == "tag":
            method = "tag"
            msg = "Tag '{}'".format(tag)
            msg_suffix = "(import from VCF file)"
        else:
            method = "rnd"
            msg = "None"
            msg_suffix = "(maf set to 0.5)"
    else:
        method = "file"
        if id_idx is None:
            msg = "[CHR({})][POS({})][REF({})][ALT({})][MAF({})]".format(chr_idx, pos_idx, ref_idx, alt_idx, maf_idx)
        else:
            msg = "[CHR({})][POS({})][ID({})][REF({})][ALT({})][MAF({})]".format(chr_idx, pos_idx, id_idx, ref_idx,
                                                                                 alt_idx, maf_idx)
        msg_suffix = "(columns of freq. file)"

    # generate random seed if necessary
    if seed is None:
        sq = np.random.SeedSequence()
        seed = sq.generate_state(1)[0]
    rng = default_rng(seed)  # init random number generator

    # give visual feedback and write the log
    if method == "file":
        vcf_rnd = "{}.bak".format(prefix)
    else:
        vcf_rnd = "{}.vcf".format(prefix)
    log_file = "{}.log".format(prefix)
    asc_file = "{}.asc".format(prefix)
    fam_file = "{}.fam".format(prefix)
    log = open(log_file, "w", encoding="utf8")

    print_msg(msg_type="Input", msg_prefix="Reference file:", msg=ref, logging_file=log)
    print_msg(msg_prefix="Frequency values:", msg=msg, msg_suffix=msg_suffix, logging_file=log)
    if n is not None:
        print_msg(msg_prefix="Number of individuals:", msg=str(n), msg_suffix="(sexes not assigned)",
                  logging_file=log)
        x_msg = "(if found, it will be ignored)"
    elif n_female is not None and n_male is not None:
        print_msg(msg_prefix="Number of individuals:", msg=str(n_female + n_male),
                  msg_suffix="(female={}, male={})".format(n_female, n_male), logging_file=log)
        x_msg = "(if present)"
    else:
        print_msg(msg_prefix="Number of individuals:", msg="missing", logging_file=log)
        x_msg = "(if found, it will be ignored)"
    print_msg(msg_prefix="X chromosome:", msg=str(x_chr), msg_suffix=x_msg, logging_file=log)
    print_msg(msg_prefix="Seed number:", msg=str(seed), logging_file=log)
    print_msg(msg_type="Output", msg_prefix="Population dataset:", msg=vcf_rnd.replace(".bak", ".vcf"),
              separator_top=True, separator="\n", logging_file=log)
    print_msg(msg_prefix="Allele sharing coefficients:", msg=asc_file, logging_file=log)
    print_msg(msg_prefix="Logging info:", msg=log_file, logging_file=log)
    if n is None and n_female is not None and n_male is not None:
        print_msg(msg_prefix="Sexes of individuals:", msg=fam_file, logging_file=log)

    # determine n if necessary
    if n is None:
        if n_female is None or n_male is None:
            print_msg(msg_type="Error", msg_prefix="'n' or 'n_female'/'n_male' not set", msg="Exiting",
                      msg_suffix="(see help for more details)", type_color="red", separator_top=True,
                      separator="\n", logging_file=log)
            end_task = True
        else:
            n = n_female + n_male
            fam = open(fam_file, "w")
    elif n_female is not None or n_male is not None:
        print_msg(msg_type="Warning", msg_prefix="'n' and 'n_female'/'n_male' set", msg="Considering only 'n'",
                  msg_suffix="(see help for more details)", type_color="yellow", separator_top=True,
                  separator="\n", logging_file=log)
        n_female = None
        n_male = None

    # if all parameters are correctly set, continue with the task
    if not end_task:

        # IDs of the individuals to be created
        ids = []
        for idx in range(n):
            if n_female is not None:  # if the sex is specified, insert it also in the ID of each individual
                if idx < n_female:  # first group of IDs are for females
                    ind_id = "{}{}F".format(ind_prefix, idx)
                    fam_msg = "{}\tF\n".format(ind_id)
                else:  # last group of IDs are for males
                    ind_id = "{}{}M".format(ind_prefix, idx)
                    fam_msg = "{}\tM\n".format(ind_id)
                fam.write(fam_msg)
            else:
                ind_id = "{}{}".format(ind_prefix, idx)
            ids.append(ind_id)

        ref_in = open(ref, "r")
        vcf_out = open(vcf_rnd, "w")

        # initialize allele sharing coefficient lists and SNPs count
        asc_autosome = [0] * int(n * (n - 1) / 2)
        n_autosome = 0
        asc_x = [0] * int(n * (n - 1) / 2)
        n_x = 0

        print_msg()  # empty line for visual feedback

        # variables to handle the progress bar
        prg_n = 0
        txt_chr = ""
        refresh = True

        contig = []  # will contain [chr, length] identifying chromosome ID and length (i.e., last position + 1)

        for line in ref_in:  # for each line in the VCF file
            # if necessary update the progress bar
            if refresh:
                if prg_n > 0:
                    txt = "(chromosome {})".format(txt_chr)
                else:
                    txt = ""
                print_msg(msg_prefix="Generating individuals:", msg_suffix=txt, progress_bar=[prg_n, 24, 15])
                refresh = False

            # analyze the line
            if not method == "file":  # minor allele frequency in the VCF file as tag or fully randomized
                if line.startswith("##"):  # comments are re-written unchanged
                    vcf_out.write(line)  # write the line on the output file
                else:
                    if line.startswith("#CHROM"):  # header: update the IDs
                        values = line.split()
                        values = values[0:9] + ids
                    else:  # SNP line: update the individuals' values
                        values = line.split()
                        values = values[0:9]

                        # keep track of position for contig tags in the VCF header
                        if len(contig) == 0:  # first chromosome
                            contig.append([values[0], values[1]])
                        else:

                            # update the last position since we are still within the same chromosome
                            if contig[-1][0] == values[0]:
                                contig[-1][1] = values[1]
                            else:  # pass to new chromosome, finalize previous one and initialize the new one
                                contig[-1][1] = str(int(contig[-1][1]) + 1)
                                contig.append([values[0], values[1]])

                        # check if you need to update the progress bar
                        try:
                            cur_chr = int(values[0])
                        except ValueError:
                            cur_chr = 23  # the X chromosome
                        if not cur_chr == prg_n:
                            prg_n = prg_n + 1
                            txt_chr = values[0]
                            refresh = True

                        if method == "tag":  # extract maf from the vcf line
                            val = extract_freq(info=values[7], tag=tag)
                            maf = val
                            if maf > 0.5:
                                warn_msg = "The tag '{}' contains frequency values bigger than 0.5. Thus, it doesn't " \
                                           "refer to MAF.".format(tag)
                                warnings.warn(warn_msg)
                                maf = 1 - val

                        elif method == "rnd":  # randomly select between reference and alternate base, i.e., 0.5
                            maf = 0.5
                            val = 0.5

                        ind_values = rnd_snp(values[0], x_chr, n, n_female, n_male,
                                             val, invert_maf, rng, log, skip_x)
                        if ind_values:
                            values = values + ind_values

                            if 0 < float(maf) < 1:
                                if str(values[chr_idx]) == str(x_chr):
                                    asc_x = update_asc(asc_x, ind_values, maf)
                                    n_x = n_x + 1
                                else:
                                    asc_autosome = update_asc(asc_autosome, ind_values, maf)
                                    n_autosome = n_autosome + 1

                        else:
                            skip_x = True

                    line = "\t".join(values) + "\n"  # re-assemble the line

                    # always write if it is not the X chromosome or
                    # if it is the X chromosome and the skip_x flag is False
                    if (not values[0] == str(x_chr)) or (values[0] == str(x_chr) and not skip_x):
                        vcf_out.write(line)  # write the line on the output file
            else:  # 'ref' file contains alternate allele frequency information, will create VCF file from scratch
                if header > 0:  # number of header lines to skip
                    header = header - 1
                else:
                    values = line.split()

                    # keep track of position for contig tags in the VCF header
                    if len(contig) == 0:  # first chromosome
                        contig.append([values[chr_idx], values[pos_idx]])
                    else:

                        # update the last position since we are still within the same chromosome
                        if contig[-1][0] == values[chr_idx]:
                            contig[-1][1] = values[pos_idx]
                        else:  # pass to new chromosome, finalize previous one and initialize the new one
                            contig[-1][1] = str(int(contig[-1][1]) + 1)
                            contig.append([values[chr_idx], values[pos_idx]])

                    # check if you need to update the progress bar
                    try:
                        cur_chr = int(values[chr_idx])
                    except ValueError:
                        cur_chr = 23  # the X chromosome
                    if not cur_chr == prg_n:
                        prg_n = prg_n + 1
                        txt_chr = values[chr_idx]
                        refresh = True

                    # if no ID info is available insert missing value
                    if id_idx is None:
                        id_val = "."
                    else:
                        id_val = str(values[id_idx])

                    # insert also the alternate frequency value in the INFO column of the VCF with the predefined TAG

                    # NOTE: WAS IMPLEMENTED TO STORE THE REAL MAF VALUE
                    # val = str(values[maf_idx])
                    # maf = val
                    # if float(maf) > 0.5:
                    #     maf = str(1 - float(maf))
                    maf = str(values[maf_idx])  # store the alternate frequency value

                    info_val = "{}={}".format(tag, maf)

                    # assemble the columns with the main info about the current SNP
                    vcf_values = [str(values[chr_idx]), str(values[pos_idx]), id_val, str(values[ref_idx]),
                                  str(values[alt_idx]),
                                  ".", ".", info_val, "GT"]

                    # add the randomly generated SNPs of all individuals
                    ind_values = rnd_snp(values[chr_idx], x_chr, n, n_female, n_male,
                                         maf, invert_maf, rng, log, skip_x)
                    if ind_values:
                        vcf_values = vcf_values + ind_values
                        if 0 < float(maf) < 1:
                            if str(values[chr_idx]) == str(x_chr):
                                asc_x = update_asc(asc_x, ind_values, float(maf))
                                n_x = n_x + 1
                            else:
                                asc_autosome = update_asc(asc_autosome, ind_values, float(maf))
                                n_autosome = n_autosome + 1

                    else:
                        skip_x = True

                    line = "\t".join(vcf_values) + "\n"  # re-create the line

                    # always write if it is not the X chromosome or
                    # if it is the X chromosome and the skip_x flag is False
                    if (not values[chr_idx] == str(x_chr)) or (values[chr_idx] == str(x_chr) and not skip_x):
                        vcf_out.write(line)

        # close all opened files
        ref_in.close()
        vcf_out.close()
        if n_female is not None:
            fam.close()

        if method == "file":

            # header for output VCF file when created from scratch
            vcf_top_header = "##fileformat=VCFv4.2\n##fileDate={}\n##source=aDNA_Tools_rnd_pop_v{}\n".format(
                date.today().strftime('%Y%m%d'), __version__)
            vcf_reference = "##reference={}\n".format(os.path.realpath(ref))
            vcf_format_header = "##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n"
            vcf_info_header = "##INFO=<ID=AFngsrelate,Number=A,Type=Float,Description=\"Allele Frequency\">\n"
            vcf_header = ["#CHROM", "POS", "ID", "REF", "ALT", "QUAL", "FILTER", "INFO", "FORMAT"]
            vcf_contig = "##contig=<ID={},length={}>"

            f_vcf = open("{}.vcf".format(prefix), "w")  # final VCF version with header
            i_vcf = open(vcf_rnd, "r")  # temporary BAK file

            f_vcf.write(vcf_top_header)
            f_vcf.write(vcf_reference)
            for c in contig:
                if not skip_x or not str(c[0]) == str(x_chr):
                    f_vcf.write(vcf_contig.format(c[0], c[1]) + "\n")
            f_vcf.write(vcf_format_header)
            f_vcf.write(vcf_info_header)
            f_vcf.write("\t".join(vcf_header + ids) + "\n")
            for line in i_vcf:
                f_vcf.write(line)
            f_vcf.close()
            i_vcf.close()
            os.remove(vcf_rnd)  # remove temporary BAK file

        # end of task, one last update to the progress bar
        print_msg(msg_prefix="Generating individuals:", progress_bar=[24, 24, 15])

        print_msg()  # empty line for visual feedback

        # export the allele sharing coefficient estimates among the generated individuals
        for idx in range(len(asc_autosome)):
            if n_autosome > 0:
                asc_autosome[idx] = asc_autosome[idx] / n_autosome
            else:
                asc_autosome[idx] = '-'
            if n_x > 0:
                asc_x[idx] = asc_x[idx] / n_x
            else:
                asc_x[idx] = '-'

        n_ids = len(ids)
        asc_idx = 0
        asc_out = open(asc_file, "w")
        asc_out.write("ID 1\tID 2\tASC autosome\tASC X chromosome\n")
        for idx_1 in range(n_ids - 1):
            for idx_2 in range(idx_1 + 1, n):
                asc_out.write("{}\t{}\t{}\t{}\n".format(ids[idx_1], ids[idx_2], asc_autosome[asc_idx], asc_x[asc_idx]))
                asc_idx = asc_idx + 1
        asc_out.close()

        # feedback on the final status
        print_msg(msg_type="Done", msg="Population successfully created", separator_top=True, separator="\n",
                  logging_file=log)
    else:

        # feedback on the final status
        print_msg(msg_type="Done", msg="Failed to create population", separator_top=True, separator="\n",
                  logging_file=log)

    log.close()  # close logging


def sym_combo(combo: tuple) -> tuple:
    """
    Create symmetrical combination for sexes in automatic pedigree generation
    :param list combo: The combination to analyze
    :return: list: Symmetrical version of the combination"""

    s_combo = []
    for c in combo:
        if type(c) is tuple:
            if len(c) == 2:
                s_combo.append(tuple([c[1], c[0]]))
            else:
                if (len(c) % 2) == 0:
                    print("NOTE: Symmetrical check (sym_combo) found a combination longer than two.")
                    print("      Assuming branches of two individuals each starting from left to right.")
                    print("      (Length of combination is even)")
                    print("Combination: {}".format(c))
                    left_cmb = list(c)
                    right_cmb = left_cmb[2:]
                    left_cmb = left_cmb[0:2]
                    if len(right_cmb) == 1:
                        right_cmb = right_cmb[0]
                    else:
                        right_cmb = tuple(right_cmb)
                    sym_c = tuple([right_cmb, tuple(left_cmb)])
                    print("Assuming: {}".format(tuple([tuple(left_cmb), right_cmb])))
                    sym_c = sym_combo(sym_c)
                    print("Symmetrical assumption: {}".format(sym_c))
                    sym_l = []
                    for s in sym_c:
                        if type(s) is tuple:
                            sym_l = sym_l + list(s)
                        else:
                            sym_l.append(s)
                    print("Symmetrical combination: {}\n".format(tuple(sym_l)))
                    s_combo.append(tuple(sym_l))
                else:
                    print("NOTE: Symmetrical check (sym_combo) found a combination longer than two.")
                    print("      Assuming branches of one individual each starting from left to right.")
                    print("      (Length of combination is odd)")
                    print("Combination: {}".format(c))
                    sym_c = c[::-1]  # revert the tuple
                    print("Symmetrical combination: {}\n".format(sym_c))
                    s_combo.append(sym_c)
        else:
            s_combo.append(c)

    return tuple(s_combo)


# noinspection PyUnboundLocalVariable
def parse_idx(idx_file: str) -> dict:
    """
    Parse the IDX file to extract the relevant settings of the specific relationship.
    Returns a dictionary with all the relevant parameters and combinations to execute
    the ped-sim scripts. It also creates the DEF files for all possible combinations.
    Ex.:
    dict: {'Parent-Offspring(2nd-Cousins_Inbreed)_F_F': ('1', [(1, '0', '2'), (3, '0', '2')],
            ...
          }
    An entry in the dictionary is a name of a relationship (notably inclusive of the gender, in this case
    parent-offspring F and F, i.e., mother-daughter). The data structure associated with the relationship contains
    its degree, i.e., 1, and the list of references to the combinations where that relationship can be found, i.e.,
    for the combination 1 where parent is identified by the index 0 and the offspring identified by the index 2; for
    the combination 3 where parent is identified by the index 0 and the offspring identified by the index 2
    It also includes:
    - The prefix of the generated DEF files (the entry "def" of the dictionary)
      Ex.: "prefix_{}.def"
    - The number of combinations ("n")
    :param str idx_file: The IDX file with all the settings for a specific relationship
    :return dict: Relevant parameters extracted from the given IDX file"""

    in_file = open(idx_file, "r")  # file with the settings
    g_dict = {}
    gens = []
    ind = {}
    roi = False
    rels = {}
    sym_skip = []
    for line in in_file:  # for each line in the IDX file
        if line.startswith("<M="):  # associations with MALE and FEMALE values
            m = re.match(r'<M=(.*) F=(.*)>', line)
            m_coeff = int(m.group(1))
            # f_coeff = int(m.group(2))
            # print("Male={}".format(m_coeff))
            # print("Female={}".format(f_coeff))
        elif line.startswith("<G="):  # definition of a generation
            m = re.match(r'<G=(.*):(.*)>', line)  # extract parameters by matching the syntax
            if "*" in m.group(1):
                gen = m.group(1).replace("*", "")
                sym_skip.append(gen)
            else:
                gen = m.group(1)  # generation number
            gens.append(gen)
            g_dict[gen] = []
            seq = m.group(2)  # accepted gender combinations across the branches for the current generation
            res = seq.strip('][').split(' ')
            for r in res:
                if r.startswith("("):
                    t = ast.literal_eval(r.replace("_", "-1"))
                    g_dict[gen].append(t)
                else:
                    g_dict[gen].append(int(r))
        elif line.startswith("<IDX="):  # definition of individuals of interest
            m = re.match(r'<IDX=(.*):(.*)>', line)
            ind[m.group(1)] = m.group(2)
        elif line.startswith("#IDX1"):
            roi = True  # tabbed columns are beginning from the next line
        elif roi:
            vals = line.rstrip().split("\t")
            if len(vals) == 4:
                if vals[2] not in rels:
                    rels[vals[2]] = (vals[3], [])
                rels[vals[2]][1].append((vals[0], vals[1]))
    in_file.close()
    g_sort = sorted(g_dict)

    # prepare list of combinations and account for symmetrical combinations to be removed as duplicates
    combinations = it.product(*(g_dict[g] for g in g_sort))
    combinations = list(combinations)
    combo_set = set()
    combo_samples = []
    combo_idx = 0
    # combos = {}
    for comb in combinations:
        if sym_skip:
            tmp = list(comb)
            for s in sym_skip:
                tmp[int(s) - 1] = -1
            tmp = tuple(tmp)
        else:
            tmp = comb
        if not combo_set or tmp not in combo_set:
            combo_set.add(tmp)
            combo_set.add(sym_combo(tmp))
            combo_samples.append(comb)  # NOTE: here we save the unmodified version
            # combos[combo_idx] = {}
            combo_idx += 1

    # evaluate the gender for each individual in each combination
    idx_combo = 0
    combo_dict = {}
    for combo in combo_samples:
        combo_ind_sex = {}
        idx_g = 0
        def_source = idx_file.replace(".idx", ".def")
        def_combo = def_source.replace(".def", "_{}.def".format(idx_combo + 1))
        def_in = open(def_source, "r")
        def_out = open(def_combo, "w")
        for line in def_in:
            if "{}" not in line:
                def_out.write(line)
            else:
                m_label = ""
                f_label = ""
                if type(combo[idx_g]) is not int:
                    offset = 0
                    for idx_branch in range(len(combo[idx_g])):
                        if combo[idx_g][idx_branch] == -1:
                            offset += 1
                        elif combo[idx_g][idx_branch] == m_coeff:
                            combo_ind_sex["({},{})".format(line.split(" ")[0], idx_branch + 1 - offset)] = "M"
                            if m_label:
                                m_label = "{},{}".format(m_label, idx_branch + 1 - offset)
                            else:
                                m_label = "{}".format(idx_branch + 1 - offset)
                        else:
                            combo_ind_sex["({},{})".format(line.split(" ")[0], idx_branch + 1 - offset)] = "F"
                            if f_label:
                                f_label = "{},{}".format(f_label, idx_branch + 1 - offset)
                            else:
                                f_label = "{}".format(idx_branch + 1 - offset)
                    line_label = ""
                    if m_label:
                        line_label = m_label + "sM"
                    if f_label:
                        if line_label:
                            line_label = "{} {}sF".format(line_label, f_label)
                        else:
                            line_label = f_label + "sF"
                else:
                    if combo[idx_g] == m_coeff:
                        combo_ind_sex["({},1)".format(line.split(" ")[0])] = "M"
                        line_label = "1sM"
                    else:
                        combo_ind_sex["({},1)".format(line.split(" ")[0])] = "F"
                        line_label = "1sF"
                def_out.write(line.format(line_label))
                idx_g += 1

        def_in.close()
        def_out.close()
        for key, value in rels.items():
            entry = key
            for v in value[1]:
                sex_1 = combo_ind_sex[ind[v[0]]]
                sex_2 = combo_ind_sex[ind[v[1]]]
                if "{}_{}_{}".format(entry, sex_1, sex_2) not in combo_dict:
                    combo_dict["{}_{}_{}".format(entry, sex_1, sex_2)] = (value[0], [])
                combo_dict["{}_{}_{}".format(entry, sex_1, sex_2)][1].append((idx_combo + 1, v[0], v[1]))
        idx_combo += 1

    combo_dict["n"] = idx_combo
    combo_dict["def"] = def_source.replace(".def", "_{}.def")
    # for key, value in combo_dict.items():
    #     print("- {}:\n".format(key))
    #     print("       Degree: {}\n".format(value[0]))
    #     for v in value[1]:
    #         print("       Combo #{}: ({}, {})\n".format(v[0], v[1], v[2]))

    return combo_dict


# noinspection PyUnboundLocalVariable,PyTypeChecker
def vcf2asc(vcf_file: str, tag="AFngsrelate", x_chr="X", chr_idx=0):
    """
    Compute the allele sharing coefficient between samples of a given VCF file.
    Results are stored in an ASC file (text file) having the same name of the input VCF file
    :param str vcf_file: Reference VCF or minor allele frequency file
    :param str, optional tag: MAFs are stored  within  the reference  VCF file,  consider the given TAG  (default
    'AFngsrelate')
    :param optional x_chr: Label associated with the X chromosome (default 'X')
    :param int, optional chr_idx: Column  index for chromosome  details (default 0)"""

    maf_idx = 7  # TAG column
    asc_file = vcf_file.replace(".vcf", ".asc")  # output file
    vcf_in = open(vcf_file, "r")  # input file
    for line in vcf_in:
        if line.startswith("#CHROM"):
            values = line.split()
            ids = values[9:]

            # initialize allele sharing coefficient lists and SNPs count
            n = len(ids)
            asc_autosome = [0] * int(n * (n - 1) / 2)
            n_autosome = 0
            asc_x = [0] * int(n * (n - 1) / 2)
            n_x = 0
        elif not line.startswith("#"):
            values = line.split()
            maf = extract_freq(info=values[maf_idx], tag=tag)
            ind_values = values[9:]
            if 0 < float(maf) < 1:
                if str(values[chr_idx]) == str(x_chr):
                    asc_x = update_asc(asc_x, ind_values, maf)
                    n_x = n_x + 1
                else:
                    asc_autosome = update_asc(asc_autosome, ind_values, maf)
                    n_autosome = n_autosome + 1
    vcf_in.close()

    for idx in range(len(asc_autosome)):
        if n_autosome > 0:
            asc_autosome[idx] = asc_autosome[idx] / n_autosome
        else:
            asc_autosome[idx] = '-'
        if n_x > 0:
            asc_x[idx] = asc_x[idx] / n_x
        else:
            asc_x[idx] = '-'

    n_ids = len(ids)
    asc_idx = 0
    asc_out = open(asc_file, "w")
    asc_out.write("ID 1\tID 2\tASC autosome\tASC X chromosome\n")
    for idx_1 in range(n_ids - 1):
        for idx_2 in range(idx_1 + 1, n):
            asc_out.write("{}\t{}\t{}\t{}\n".format(ids[idx_1], ids[idx_2], asc_autosome[asc_idx], asc_x[asc_idx]))
            asc_idx = asc_idx + 1
    asc_out.close()


# noinspection PyUnboundLocalVariable,PyTypeChecker
def kinship_windowed(g_data: list, win_len: int, win_shift: int, phased=False) -> list:
    """
    Estimate the allele sharing coefficient and mismatch coefficient over a shifting window for a given set of SNPs
    :param list g_data: The data block to be analyzed (in the form of [ [CHR, POS, MAF, Value 1, ..., Value n], ... ])
    With CHR as a string, POS as an integer, MAF as a floating value and Value 1, ..., Value n as string in the form of
    "0|0", "0|1", "1|0", "1|1", "1" or "0"
    :param int win_len: Size of the window within which the allele sharing coefficient is estimated (in terms of number
    of positions)
    :param int win_shift: Shift size (in terms of number of positions)
    :param bool, optional phased: If set it assumes the data to be phased. Default behavior unphased (affects only the
    mismatch coefficient)
    :return list: A list of two items is returned. The first item contains the data structure (as described above) for
    the allele sharing coefficient, whereas the second item contains the data structure (as described above) for the
    mismatch coefficient"""

    # sanity check for the input g_data
    check_chr = None
    for dt in g_data:
        if check_chr is None:
            check_chr = dt[0]
        else:
            if not check_chr == dt[0]:
                msg = "g_data not consistent, multiple chromosome found: {} and {}.".format(check_chr, dt[0])
                raise ValueError(msg)

    asc_win = []  # returned data structure for asc
    msm_win = []  # returned data structure for msm
    if win_shift > win_len:
        print("Shifting of the windows cannot be bigger that the window size.")
        print("Setting window shift equal to window size.")
        win_shift = win_len
    asc_next_start = 0  # used to determine the starting index for the next window
    msm_next_start = 0  # used to determine the starting index for the next window
    asc_start_idx = asc_next_start  # starting index of the window
    msm_start_idx = msm_next_start  # starting index of the window
    stop = False  # flag to stop the loop
    asc_stop = False
    msm_stop = False
    while not stop:
        # initialize allele sharing coefficient lists and SNPs count for the current segment
        n = len(g_data[0][3:])  # number of samples/individuals
        asc_seg = [0] * int(n * (n - 1) / 2)  # number of combinations among individuals
        msm_seg = [0] * int(n * (n - 1) / 2)  # number of combinations among individuals

        asc_idx = asc_start_idx  # first value to be considered is at the starting index of the window
        msm_idx = msm_start_idx  # first value to be considered is at the starting index of the window
        asc_n_seg = 0
        msm_n_seg = 0
        done = False
        asc_done = False
        msm_done = False
        while not done:  # continue until the length of the SNP values does not reach the window length
            try:
                if not msm_stop and msm_n_seg < win_len:
                    msm_ind_values = g_data[msm_idx][3:]  # sample values from individuals
                    msm_seg = update_msm(msm_seg, msm_ind_values, phased)  # update the msm with the new values
                    msm_n_seg += 1
                    if msm_n_seg == win_shift:  # if necessary save the index where the next window will start
                        msm_next_start = msm_idx + 1
                else:
                    msm_done = True
            except IndexError:  # last window may not have all the SNPs required in a window, finalize it as it is
                msm_stop = True
                msm_finalized = False

            try:
                if not asc_stop and asc_n_seg < win_len:
                    asc_ind_values = g_data[asc_idx][3:]  # sample values from individuals
                    maf = g_data[asc_idx][2]  # alternate allele frequency
                    if 0 < float(maf) < 1:  # a value we can use (if not we do not count it for the window length)
                        asc_seg = update_asc(asc_seg, asc_ind_values, maf)  # update the asc with the new values
                        asc_n_seg += 1
                        if asc_n_seg == win_shift:  # if necessary save the index where the next window will start
                            asc_next_start = asc_idx + 1
                else:
                    asc_done = True
            except IndexError:  # last window may not have all the SNPs required in a window, finalize it as it is
                asc_stop = True
                asc_finalized = False

            done = asc_done and msm_done
            asc_idx += 1
            msm_idx += 1

        # segment completed, finalize asc and msm value
        if (not asc_stop) or (asc_stop and not asc_finalized):
            for idx in range(len(asc_seg)):
                if asc_n_seg > 0:
                    asc_seg[idx] = asc_seg[idx] / asc_n_seg
                else:
                    asc_seg[idx] = '-'
            if len(asc_seg) == 1:
                asc_win.append(tuple([asc_n_seg, asc_seg[0]]))
            else:
                asc_win.append(tuple([asc_n_seg, tuple(asc_seg)]))
            if asc_stop and not asc_finalized:
                asc_finalized = True

        if (not msm_stop) or (msm_stop and not msm_finalized):
            for idx in range(len(msm_seg)):
                if msm_n_seg > 0:
                    msm_seg[idx] = msm_seg[idx] / (2 * msm_n_seg)
                else:
                    msm_seg[idx] = '-'
            if len(msm_seg) == 1:
                msm_win.append(tuple([msm_n_seg, msm_seg[0]]))
            else:
                msm_win.append(tuple([msm_n_seg, tuple(msm_seg)]))
            if msm_stop and not msm_finalized:
                msm_finalized = True

        asc_start_idx = asc_next_start  # update starting index for the new window
        msm_start_idx = msm_next_start  # update starting index for the new window

        stop = asc_stop and msm_stop

    return [asc_win, msm_win]


# noinspection PyUnboundLocalVariable
def dynamic_kinship(vcf_file: str, win_len: int, win_shift: int,
                    tag="AFngsrelate", chr_idx=0, pos_idx=1, phased=False) -> list:
    """
    Compute the dynamic allele sharing coefficient (ASC) and the mismatch (MSM) coefficient between samples of a given
    VCF file. Dynamic refers to the ASC estimated within a given window size throughout the available SNPs
    :param str vcf_file: Input VCF file
    :param int win_len: Size of the window within which the allele sharing coefficient is estimated (in terms of number
    of SNPs)
    :param int win_shift: Shift size (in terms of number of SNPs)
    :param str, optional tag: MAFs are stored  within  the reference  VCF file,  consider the given TAG  (default
    'AFngsrelate')
    :param int, optional chr_idx: Column  index for chromosome  details (default 0)
    :param int, optional pos_idx: Column  index for SNP position (default 1)
    :param bool, optional phased: If set it assumes the data to be phased. Default behavior unphased (affects only the
    mismatch coefficient)"""

    idx_ref = {}
    idx = 0
    chrom = "-"
    vcf_in = open(vcf_file, "r")
    found_maf = False
    for line in vcf_in:
        line = line.strip('\n')
        if line.startswith("#CHROM"):
            values = line.split("\t")
            ids = values[9:]
            samples_data = []  # each entry is a list: [CHR, POS, MAF, V1, V2, ..., Vn]
        elif not line.startswith("#"):
            values = line.split("\t")
            maf = extract_freq(info=values[7], tag=tag)
            if not maf == -1:  # if there is at least one frequency value we retain all ASC computations
                found_maf = True
            ind_values = values[9:]
            samples_data.append([values[chr_idx], int(values[pos_idx]), maf] + ind_values)
            if chrom != values[chr_idx]:
                if chrom != "-":
                    idx_ref[chrom] = (idx_ref[chrom], idx - 1)
                idx_ref[values[chr_idx]] = idx
                chrom = values[chr_idx]
            idx += 1
    idx_ref[values[chr_idx]] = (idx_ref[values[chr_idx]], idx - 1)
    vcf_in.close()

    idxs = []
    for idx1 in range(len(ids)):
        for idx2 in range(idx1 + 1, len(ids)):
            idxs.append((idx1, idx2))
    asc_chr = {"id": ids,
               "idx": idxs
               }
    msm_chr = {"id": ids,
               "idx": idxs
               }

    for key, val in idx_ref.items():
        [asc_chr[key], msm_chr[key]] = kinship_windowed(samples_data[val[0]: val[1] + 1], win_len, win_shift, phased)

    if not found_maf:
        asc_chr = ["DISCARD", asc_chr]  # data are still returned (used later to create labels and indices for msm)
        warn_msg = "No frequency values were found in the VCF file under the tag '{}'. Therefore, the ASC analysis " \
                   "has been discarded.".format(tag)
        warnings.warn(warn_msg)

    return [asc_chr, msm_chr]


def maf2vcf(frq_file: str, vcf_file: str):
    """
    Insert the frequency values stored in a file into the VCF file
    :param str frq_file : The file that contains the frequency values
    :param str vcf_file : The VCF file where the frequency values will be added"""

    info_header = "##INFO=<ID=AFngsrelate,Number=A,Type=Float,Description=\"Allele Frequency\">\n"  # ngsRelate TAG
    af_defined = False  # flag to avoid to insert twice the ngsRelate TAG if already there

    old_file = vcf_file + ".old"  # backup/old file name
    shutil.copy(vcf_file, old_file)  # copy the original file (so it is not lost)
    frq = open(frq_file, "r")  # frequency file pointer

    vcf_in = open(old_file, "r")  # input VCF file pointer
    vcf_out = open(vcf_file, "w")  # output VCF file pointer

    info_idx = -1  # will contain the index for the INFO column
    entry_line = 0
    for line in vcf_in:  # for each line in the file
        if line.startswith("##"):  # header: copy it to the new file
            if line.startswith("##INFO") and "ID=AFngsrelate" in line:  # TAG was already in the header
                af_defined = True
            vcf_out.write(line)
        elif line.startswith("#CHROM"):  # column header: we need to find the index for the INFO column
            if not af_defined:  # before adding the column names, if necessary add the TAG line
                vcf_out.write(info_header)
            header = line.split()  # decompose the line

            # Identify the index of the INFO column:
            #
            info_idx = 0
            found = False
            while not found and info_idx < len(header):
                if header[info_idx] == "INFO":
                    found = True
                else:
                    info_idx = info_idx + 1

            if not found:  # the INFO column is not in the file, throw an error
                # Close the opened files:
                #
                vcf_in.close()
                vcf_out.close()
                frq.close()

                __restore_vcf(vcf_file)  # restore the original file

                msg = "INFO column not found in the VCF file '{}'".format(vcf_file)
                raise ValueError(msg)

            vcf_out.write(line)  # write on the output file
        else:  # data row: we need to select the INFO field and add the frequency value
            entry_line = entry_line + 1
            # Read the VCF line details:
            #
            entry = line.split()  # decompose the line
            prv_value = entry[info_idx]  # previous INFO value

            # Read the frequency details:
            #
            frq_entry = frq.readline()
            while frq_entry.startswith(
                    "#"):  # or frq_entry == "":  # header or empty line, discard and read the next line
                frq_entry = frq.readline()  # read (and discard) the header of the frequency file which won't be used

            if not frq_entry:
                vcf_in.close()
                vcf_out.close()
                frq.close()

                __restore_vcf(vcf_file)  # restore the original file

                msg = "Unexpected end of frequency file: The frequency file has less entries than the VCF file."
                raise ValueError(msg)

            frq_entry = frq_entry.strip('\n')
            try:
                _ = float(frq_entry)  # check if it is really a data line
            except ValueError:  # a header without the #, read and split the next line
                vcf_in.close()
                vcf_out.close()
                frq.close()

                __restore_vcf(vcf_file)  # restore the original file

                msg = "Unexpected frequency value: '{}'".format(frq_entry)
                raise ValueError(msg)

            if prv_value == ".":  # if empty just insert the TAG value
                entry[info_idx] = "AFngsrelate={}".format(frq_entry)
            elif prv_value[-1] == ";":  # if not empty attach the TAG at the end
                entry[info_idx] = entry[info_idx] + "AFngsrelate={}".format(frq_entry)
            else:  # if not empty attach the TAG at the end
                entry[info_idx] = entry[info_idx] + ";AFngsrelate={}".format(frq_entry)

            # Create the new line and write it to the output file:
            #
            new_line = "\t".join(entry)
            new_line = new_line + "\n"
            vcf_out.write(new_line)  # write on the output file

    frq_entry = frq.readline()
    while frq_entry.startswith("#"):  # or frq_entry == "":  # header or empty line, discard and read the next line
        frq_entry = frq.readline()  # read (and discard) the header of the frequency file which won't be used

    if not frq_entry:
        # Close the opened files:
        #
        vcf_in.close()
        vcf_out.close()
        frq.close()
    else:
        vcf_in.close()
        vcf_out.close()
        frq.close()

        __restore_vcf(vcf_file)  # restore the original file

        msg = "Unexpected values from frequency file: The frequency file has more entries than the VCF file."
        raise ValueError(msg)


def __restore_vcf(vcf_file: str, suffix=".old"):
    """
    Restore the previous version of the VCF file (if any)
    :param str vcf_file :  The original name (i.e., without the .old suffix) of the file that needs to be restored
    :param str, optional suffix : The suffix extension attached to the file"""

    old_file = vcf_file + suffix  # name of the backup/old file
    old_path = Path(old_file)
    if old_path.is_file():  # there is a file to be restored
        vcf_path = Path(vcf_file)
        if vcf_path.is_file():  # there is a file that need to be removed
            os.unlink(vcf_file)  # remove the file
        shutil.move(old_file, vcf_file)  # restore the previous file
    else:
        msg = "The VCF file '{}' has no previous version.".format(vcf_file)
        raise ValueError(msg)


# noinspection PyUnboundLocalVariable
def summary(vcf_file: str, missing_values=0, check_alt=True, feedback=False) -> dict:
    """
    Verifies that the sequence of chromosomes (and locations) is in ascending order, looks for duplicate entries and
    unsupported values (with the flag 'rm_missing_value', it also tracks the presence of missing values).
    It returns a dictionary with a general summary of the dataset, i.e. the list of all chromosomes
    and recorded positions, total number of SNPs alongside with all the misplaced, duplicate and unsupported entries
    (i.e., line number with the counting starting from line 0) and, if required, missing values. A summary file is
    created to record all the problematic lines ('summary_filename.vcf'). Among unsupported SNP checks there are also
    missing reference values. It checks also for alternate missing values coupled with samples referring to it, i.e.,
    having 1s, option included in the default behavior (to ignore such cases just set the check_alt flag to False).

    int, snps : Total number of SNPs found in the VCF file. N.B. This value accounts also for the misplaced entries.
    [int], chromosome : A list of all the chromosomes found within the VCF file.
    [[int]], position : A list identifying all the positions of each chromosome. Given idx the index of the chromosome
        of interest in the "chromosome" key of the dictionary, all its positions are stored in position[idx].
        N.B. Duplicate entries (if any) are not counted!

        Ex.: idx = dict.chromosome.index(1), i.e., the index for chromosome 1
             dict.position[idx] contains all the positions associated with chromosome 1 (except for duplicate entries)
    [(int: line #, str: line)], unsupported_entry : A list of the VCF lines with unsupported values (including, if
        required, missing values).
    [(int: line #, str: line)], misplaced_entry : A list of the VCF lines with misplaced chromosome/position.
    [(int: line #, str: line)], duplicate_entry : A list of the duplicates VCF lines
    :param str vcf_file: The file from which the sequence will be verified
    :param int, optional missing_values: Filter the data in presence of missing data. By default, it filters all
    SNPs having any missing values, i.e., a given SNP is discarded if there is at least one individual with a missing
    value in that position (missing_values=0 as zero missing values are retained). Alternatively, it can be set to 1,
    i.e., the SNP is retained if there is at most a single missing value (e.g., ./1), otherwise it is discarded (e.g.,
    ./.). Finally, if it is set to 2 it retains also SNPs with two missing values, e.g., ./., thus not applying any
    filter. Briefly, the values allowed for the parameter missing_values are either 0, 1, or 2
    :param bool, optional check_alt: If the flag is set to True (default) the summary will identify (and track as not
    supported) the SNPs with missing values in the alternate column, provided that there is at least one
    sample/individual linked to it (i.e., its value set to 1)
    :param bool, optional feedback: If the flag is set to True it will provide a visual feedback of the ongoing
    process, otherwise it will run silently with only minimal output
    :return: dict: line numbers (starting from 0 as first line) and the lines themselves as strings
    (an empty list if the file is fully ordered)"""

    if missing_values < 0 or missing_values > 2:
        msg = "Unexpected 'missing_values' (found '{}'). " \
              "Accepted values are 0, 1 or 2. Considering default option 0. " \
              "See help for more details.".format(missing_values)
        missing_values = 0
        warnings.warn(msg)

    summary_dict = {}  # the returned dictionary

    misplaced_entry = []  # the output variable with the lines out of sequence
    duplicate_entry = []  # keeps track of duplicate entries (same chromosome and position number)
    unsupported_entry = []  # keeps track of the SNP lines having unsupported values
    chromosome = []  # keeps track of the found chromosomes
    position = []  # keeps track of all positions for each chromosome
    snps = 0  # keep count of the SNPs (not counting the possible duplicates)

    reference = -1  # the reference chromosome throughout the sequence
    reference_position = -1  # the position of the reference chromosome

    idx_line = 0  # line index

    misplaced = False  # the flag is set whenever a misplaced entry is found
    duplicate = False  # the flag is set whenever a duplicate entry is found
    unsupported = False  # the flag is set whenever an unsupported entry is found
    duplicate_warning = False  # duplicate flag used for "short" warning feedback
    misplaced_warning = False  # misplaced flag used for "short" warning feedback
    unsupported_warning = False  # unsupported flag used for "short" warning feedback

    vcf = open(vcf_file, "r")
    log_needed = False
    for line in vcf:
        if not (line.startswith("#")):  # not a comment line, hence a line to examine
            line_cols = line.split()  # separate the columns
            if not line_cols[0].lower() == "x":
                current_chromosome = int(line_cols[0])  # chromosome number for the current line
            else:
                current_chromosome = "X"
            current_position = int(line_cols[1])  # position number for the current chromosome

            # check SNPs values for the current line
            snp_reference = line_cols[3]
            snp_alternate = line_cols[4]
            snp_values = line_cols[9:]
            for snp_value in snp_values:
                snp = clean_snp(snp_value)
                if len(snp) == 1:
                    if missing_values == 0 and snp == ".":
                        unsupported = True
                        break
                    elif not (snp == "0" or snp == "1" or snp == "."):
                        unsupported = True
                        break
                    if check_alt and snp_alternate == "." and snp == "1":
                        unsupported = True
                        break
                elif len(snp) > 1:
                    snp_1 = snp[0]
                    snp_2 = snp[2]
                    if missing_values == 0 and (snp_1 == "." or snp_2 == "."):
                        unsupported = True
                        break
                    elif missing_values == 1 and snp_1 == "." and snp_2 == ".":
                        unsupported = True
                        break
                    elif (not (snp_1 == "0" or
                               snp_1 == "1" or
                               snp_1 == ".")) or \
                            (not (snp_2 == "0" or
                                  snp_2 == "1" or
                                  snp_2 == ".")):
                        unsupported = True
                        break
                    if check_alt and snp_alternate == "." and (snp_1 == "1" or snp_2 == "1"):
                        unsupported = True
                        break
            if snp_reference == ".":
                unsupported = True

            if current_chromosome == reference:  # same chromosome
                idx = chromosome.index(current_chromosome)

                # if the position is increasing it is ok. Continue to the new position and update the summary
                if current_position > reference_position:
                    position[idx].append(current_position)
                    reference_position = current_position
                    snps = snps + 1  # a new SNP was found
                else:
                    # the position in not increasing thus violating the order of the sequence,
                    # or the position was already recorded thus we found a duplicate entry
                    if current_position in position[idx]:  # duplicate (and do not increase the SNP count)
                        duplicate = True
                    else:  # misplaced (and increase the SNP count)
                        position[idx].append(current_position)
                        misplaced = True
                        snps = snps + 1  # a new SNP was found (though misplaced)
            else:  # different chromosome
                if current_chromosome in chromosome:  # data pertaining to a previously encountered chromosome
                    idx = chromosome.index(current_chromosome)

                    # it is again a misplaced or duplicate entry
                    if current_position in position[idx]:  # duplicate (and do not increase the SNP count)
                        duplicate = True
                    else:  # misplaced (and increase the SNP count)
                        misplaced = True
                        position[idx].append(current_position)
                        snps = snps + 1  # a new SNP was found (though misplaced)
                else:  # we are just starting to explore a new chromosome
                    chromosome.append(current_chromosome)  # add the chromosome to the summary list
                    position.append([])  # initialize the list for the positions of the chromosome
                    position[-1].append(current_position)
                    reference = current_chromosome
                    reference_position = current_position
                    snps = snps + 1  # a new SNP was found

            if not log_needed and (unsupported or misplaced or duplicate):
                log = open("summary_{}.log".format(vcf_file), "w")
                log.write("IDX\tNOTE\tLINE\n")
                log_needed = True
            if unsupported:  # update summary for unsupported entries (and feedback if required)
                unsupported_warning = True
                unsupported_entry.append([idx_line, line])
                log.write("\t".join([str(idx_line), "Unsupported", line]))
                if feedback:
                    msg = "Unsupported chromosome entry: [{}] #CHROM {}, POS {}\nSNPs: {}".format(
                        idx_line, current_chromosome, current_position, "\t".join(snp_values))
                    logging.basicConfig(format='%(asctime)s - %(message)s', level=logging.INFO)
                    logging.info(msg)

            if misplaced:  # update summary for misplaced entries (and feedback if required)
                misplaced_warning = True
                misplaced_entry.append([idx_line, line])
                log.write("\t".join([str(idx_line), "Misplaced", line]))
                if feedback:
                    msg = "Chromosome entry misplaced: [{}] #CHROM {}, POS {} (reference #CHROM {}, POS {})".format(
                        idx_line, current_chromosome, current_position, reference, reference_position)
                    logging.basicConfig(format='%(asctime)s - %(message)s', level=logging.INFO)
                    logging.info(msg)

            if duplicate:  # update summary for duplicate entries (and feedback if required)
                duplicate_warning = True
                duplicate_entry.append([idx_line, line])
                log.write("\t".join([str(idx_line), "Duplicate", line]))
                if feedback:
                    msg = "Duplicate chromosome entry: [{}] #CHROM {}, POS {}".format(idx_line,
                                                                                      current_chromosome,
                                                                                      current_position)
                    logging.basicConfig(format='%(asctime)s - %(message)s', level=logging.INFO)
                    logging.info(msg)

            unsupported = False
            duplicate = False
            misplaced = False

        idx_line = idx_line + 1
    vcf.close()
    if log_needed:
        log.close()

    # populate the dictionary to be returned
    summary_dict["snps"] = snps
    summary_dict["chromosome"] = chromosome
    summary_dict["position"] = position
    summary_dict["unsupported_entry"] = unsupported_entry
    summary_dict["misplaced_entry"] = misplaced_entry
    summary_dict["duplicate_entry"] = duplicate_entry

    if not feedback:
        if unsupported_warning:
            n = len(unsupported_entry)
            msg = "A unsupported chromosome entry was found."
            if n > 1:
                msg = "Unsupported chromosome entries were found ({:,}).".format(n)
            logging.basicConfig(format='%(asctime)s - %(message)s', level=logging.INFO)
            logging.info(msg)
        if duplicate_warning:
            n = len(duplicate_entry)
            msg = "A duplicate chromosome entry was found."
            if n > 1:
                msg = "Duplicate chromosome entries were found ({:,}).".format(n)
            logging.basicConfig(format='%(asctime)s - %(message)s', level=logging.INFO)
            logging.info(msg)
        if misplaced_warning:
            n = len(misplaced_entry)
            msg = "A misplaced chromosome entry was found."
            if n > 1:
                msg = "Misplaced chromosome entries were found ({:,}).".format(n)
            logging.basicConfig(format='%(asctime)s - %(message)s', level=logging.INFO)
            logging.info(msg)
        if duplicate_warning or misplaced_warning:
            msg = "Try to call the function ""fix_vcf"" in order to restructure the dataset."
            logging.basicConfig(format='%(message)s', level=logging.INFO)
            logging.info(msg)

    return summary_dict


def fix_vcf(vcf_in: str, vcf_out: str, missing_values=0, feedback=True):
    """
    Given a VCF file generates a new VCF file where all misplaced entries are rearranged and duplicate entries
    as well as unsupported SNP lines are discarded. Among unsupported SNP checks there are also missing reference
    values. Checks also for alternate missing values coupled with samples referring to it, i.e., having 1s (note that
    if an alternate missing values is referenced in a sample, it is automatically discarded without considering the
    general rule about missing values, i.e., even if missing values are accepted and should be retained, the ones
    associated to the alternate value are still discarded. This is simply done for simplicity.).

    :param str vcf_in: The input VCF file (to be fixed).
    :param str vcf_out: The name of the (fixed) output VCF file.
    :param int, optional missing_values: Filter the data in presence of missing data. By default, it filters all
    SNPs having any missing values, i.e., a given SNP is discarded if there is at least one individual with a missing
    value in that position (missing_values=0 as zero missing values are retained). Alternatively, it can be set to 1,
    i.e., the SNP is retained if there is at most a single missing value (e.g., ./1), otherwise it is discarded (e.g.,
    ./.). Finally, if it is set to 2 it retains also SNPs with two missing values, e.g., ./., thus not applying any
    filter. Briefly, the values allowed for the parameter missing_values are either 0, 1, or 2.
    :param bool, optional feedback: If set the function provides a more detailed feedback,
    otherwise it will just output minimum information."""

    # examine the VCF file
    print("Scanning the file...")
    vcf_summary = summary(vcf_file=vcf_in, missing_values=missing_values, feedback=feedback)
    unsupported = vcf_summary["unsupported_entry"]
    duplicates = vcf_summary["duplicate_entry"]
    misplaced = vcf_summary["misplaced_entry"]

    msg_warning = (len(unsupported) > 0) or (len(duplicates) > 0) or (len(misplaced) > 0)
    if msg_warning:
        print("Sorting through the reported lines...")

    skip = None
    if len(unsupported) > 0:
        unsupported = entries2tab(unsupported)  # these lines are discarded as containing unsupported values
        skip = unsupported["line"]
    if len(duplicates) > 0:
        duplicates = entries2tab(duplicates)  # these lines are discarded as containing duplicates
        if skip is None:
            skip = duplicates["line"]
        else:
            skip = np.unique(np.concatenate((skip, duplicates)))  # if necessary merge and remove duplicates
    if len(misplaced) > 0:
        misplaced = entries2tab(misplaced)
        if skip is not None:  # there are lines to skip let's filter out those who are also in misplaced
            ignore_misplaced = np.intersect1d(misplaced["line"], skip)
            if len(ignore_misplaced) > 0:  # we have misplaced to ignore
                next_idx = 0
                tmp = np.zeros(len(misplaced) - len(ignore_misplaced), dtype=misplaced.dtype)
                for m_el in misplaced:
                    if m_el["line"] not in ignore_misplaced:
                        tmp[next_idx] = m_el
                        next_idx += 1
                misplaced = tmp
    start_idx = 0
    if msg_warning:
        print("Writing the VCF file...")
        last_chromosome = -1
        vcf_raw = open(vcf_in, "r")
        vcf_fix = open(vcf_out, "w")
        idx_line = -1
        ignored = 0  # used for debugging purposes
        written = 0  # used for debugging purposes
        for line in vcf_raw:
            idx_line = idx_line + 1
            if line.startswith("#"):  # comment line, rewrite it
                vcf_fix.write(line)
            else:
                [found, start_idx] = if_present(v=idx_line, v_list=skip, start_idx=start_idx)
                if not found:  # the line needs to be written, but we may add some misplaced lines before
                    # select the chromosome and position of the current line
                    values = line.split()
                    values[0] = values[0].lower().replace("x", "23")
                    line_chromosome = int(values[0])
                    line_position = int(values[1])

                    # if the line_chromosome is different from the previous written chromosome we need to be sure that
                    # we add all the remaining misplaced entries of the previous chromosome (last_chromosome)
                    if len(misplaced) > 0:
                        if not (line_chromosome == last_chromosome):
                            condition = (misplaced["chr"] == last_chromosome)
                            misplaced_chromosome = np.extract(condition, misplaced)
                            if np.size(misplaced_chromosome):
                                for row in np.nditer(misplaced_chromosome):
                                    misplaced_line = vcf_summary["misplaced_entry"][row["idx"]][1]
                                    vcf_fix.write(misplaced_line)  # write it on file

                                    # add the line to the skip list not to write it again
                                    tmp = skip
                                    skip = np.zeros(len(skip) + 1)
                                    added = 0
                                    for idx_skip in range(len(skip)):
                                        if idx_skip - added < len(tmp):
                                            if added == 0 and row["line"] < tmp[idx_skip - added]:
                                                skip[idx_skip] = row["line"]
                                                added = 1
                                                ignored -= 1  # it'll be later on ignored, but it's been already written
                                            else:
                                                skip[idx_skip] = tmp[idx_skip - added]
                                    if added == 0:
                                        skip[-1] = row["line"]
                                        ignored -= 1  # it will be later on ignored, but it has been already written

                                # drop all the entries of last_chromosome from the misplaced array
                                condition = (misplaced["chr"] != last_chromosome)
                                misplaced = np.extract(condition, misplaced)

                            last_chromosome = line_chromosome

                        # select all the misplaced entries related to the line_chromosome
                        condition = (misplaced["chr"] == line_chromosome)
                        misplaced_chromosome = np.extract(condition, misplaced)

                        # if the line_position, i.e., the position of the current file entry is smaller than
                        # the first misplaced then write the current file entry and continue to the next line,
                        # otherwise loop through the misplaced entries and insert them in the output file until
                        # the line_position can be inserted
                        while len(misplaced_chromosome) > 0 and line_position > misplaced_chromosome[0]["pos"]:
                            idx_row = misplaced_chromosome[0]["idx"]
                            misplaced_line = vcf_summary["misplaced_entry"][idx_row][1]  # misplaced line to be written
                            vcf_fix.write(misplaced_line)  # write it on file

                            tmp = skip
                            skip = np.zeros(len(skip) + 1)
                            added = 0
                            for idx_skip in range(len(skip)):
                                if idx_skip - added < len(tmp):
                                    if added == 0 and misplaced_chromosome[0]["line"] < tmp[idx_skip - added]:
                                        skip[idx_skip] = misplaced_chromosome[0]["line"]
                                        added = 1
                                        ignored -= 1  # it will be later on ignored, but it has been already written
                                    else:
                                        skip[idx_skip] = tmp[idx_skip - added]
                            if added == 0:
                                skip[-1] = misplaced_chromosome[0]["line"]
                                ignored -= 1  # it will be later on ignored, but it has been already written

                            # drop the inserted entry from both misplaced (the whole set)
                            # and misplaced_chromosome (the current one)
                            curr_line = misplaced_chromosome[0]["line"]
                            condition = (misplaced_chromosome["line"] != curr_line)
                            misplaced_chromosome = np.extract(condition, misplaced_chromosome)
                            condition = (misplaced["line"] != curr_line)
                            misplaced = np.extract(condition, misplaced)

                    vcf_fix.write(line)  # write the current line
                    written += 1
                else:
                    ignored += 1

        vcf_raw.close()
        vcf_fix.close()
        print("Output file created: {}".format(vcf_out))
        print("(Of the initial {:,} SNPs a total of {:,} SNPs were retained while the remaining {:,} SNPs were "
              "discarded. See '{}' for more details)".format(written + ignored,
                                                             written, ignored, "summary_{}.log".format(vcf_in)))
    else:
        msg = "The VCF file '{}' does not contain misplaced, duplicate or unsupported entries.".format(vcf_in)
        logging.basicConfig(format='%(asctime)s - %(message)s', level=logging.INFO)
        logging.info(msg)


def entries2tab(entries: [int, str]):
    """
    Given the misplaced_entry or duplicate_entry of the summary dictionary,
    returns a numpy array with the chromosomes and positions sorted
    :param [int, str] entries : The key of the summary dictionary where the first column identify the line
        number in the VCF file from which it was generated and str is the line itself
    :return: numpy array : The table defined as follows:
        idx : The reference index of the misplaced_entry or duplicate_entry list
        line : The line number associated with the relative misplaced/duplicate entry
        chr : The chromosome number pertinent to the text line of the misplaced/duplicate entry
        pos : The position of the chromosome pertinent to the text line of the misplaced/duplicate entry"""

    d = np.zeros(len(entries), dtype=[("idx", int), ("line", int), ("chr", int), ("pos", int)])
    for idx in range(len(entries)):
        d[idx][0] = idx
        d[idx][1] = entries[idx][0]
        values = entries[idx][1].split()
        values[0] = values[0].lower().replace("x", "23")
        d[idx][2] = int(values[0])
        d[idx][3] = int(values[1])

    d.sort(order=["chr", "pos"])

    return d


def if_present(v: int, v_list, start_idx: int) -> [bool, int]:
    done = False
    found = False
    idx = start_idx
    while not done:
        if idx >= len(v_list):
            done = True
        elif v == v_list[idx]:
            done = True
            found = True
            idx += 1
        elif (idx > 0 and v_list[idx - 1] < v < v_list[idx]) or (idx == 0 and v < v_list[idx]):
            done = True
        else:
            idx += 1

    return [found, idx]
