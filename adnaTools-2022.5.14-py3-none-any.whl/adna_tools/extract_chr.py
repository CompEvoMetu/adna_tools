import fire

__version__ = '2021.3.22'  # update also in extract_X_chr doc


def extract_chr(vcf_file: str, prefix: str, chr_id="X", pseudo_haploid=False, phased=True):
    """Extract chromosome, aDNA Tools v.2021.3.22

    Given a VCF file as input and a chromosome ID, it creates two new VCF files, where one contains only the specified
    chromosome and one with all the remaining chromosomes
    :param str, vcf_file: The input VCF file
    :param str, prefix: Prefix string for the output VCF files
    :param str, chr_id: ID of the chromosome to be extracted from the input VCF file (default X)
    :param bool, optional pseudo_haploid: Flag to convert single X strand of male into a pseudo-haploid format,
    e.g., '0' => '0|0', '1' => '1|1'
    :param bool, optional phased: Flag to determine the data format. By default, it is assumed phased and thus the
    separator '|' is considered. Alternatively, for unphased data the separator '/' will be used"""

    print("Input VCF file: {}".format(vcf_file))
    if pseudo_haploid and phased:
        separator = '|'
        print("(Phased genotype)")
    elif pseudo_haploid and not phased:
        separator = '/'
        print("(Unphased genotype)")
    else:
        separator = None
    print("Extracting chromosome: {}".format(chr_id))
    print("Prefix for output files: {}".format(prefix))

    # open files for read/write
    vcf = open(vcf_file, "r")
    out_vcf_1 = open("{}.vcf".format(prefix), "w")
    out_vcf_2 = open("{}_{}.vcf".format(prefix, chr_id), "w")

    # read line by line
    for line in vcf:
        if line.startswith("#"):  # rewrite comment lines
            out_vcf_1.write(line)
            out_vcf_2.write(line)
        else:

            # extract values of interest
            line_split = line.split()
            if line_split[0] == str(chr_id):
                if pseudo_haploid:
                    values = line_split[9:]
                    new_values = line_split[0:9]
                    for v in values:
                        if len(v) == 1:
                            new_values.append("{0}{1}{0}".format(v, separator))
                        else:
                            new_values.append(v)
                    new_line = "\t".join(new_values)
                    new_line = new_line + "\n"
                    out_vcf_2.write(new_line)
                else:
                    out_vcf_2.write(line)

            else:
                out_vcf_1.write(line)

    # close the files
    vcf.close()
    out_vcf_1.close()
    out_vcf_2.close()


if __name__ == '__main__':
    fire.Fire(extract_chr)
