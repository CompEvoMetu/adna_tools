import fire

__version__ = '2021.3.22'  # update also in split vcf doc


# noinspection PyUnboundLocalVariable
def split_vcf(source: str):
    """Split VCF, aDNA Tools v.2021.3.22

    Given an input VCF file with M samples (or a text file with a list of VCF files, one per line) it creates M VCF
    files each with a single sample. The newly created files will have the name of the source followed by an index
    Ex.: source = population.vcf
         Output files:
         population1.vcf
         population2.vcf
         ...
    :param str source: The source VCF file or text file with a list of VCF"""

    if ".vcf" in source.lower():
        f_txt = [source]
    else:
        f_txt = open(source, "r")
    for vcf in f_txt:
        vcf = vcf.rstrip()
        if vcf != "" and not vcf.startswith("#"):
            f_vcf = open(vcf, "r")
            print("Split VCF file: {}\n".format(vcf))
            for line in f_vcf:
                if line.startswith("#CHROM"):
                    values = line.split()
                    ids = values[9:]
                    break
            f_vcf.close()

            f_ids = []
            idxs = list(range(1, len(ids) + 1))
            for idx in idxs:
                f_ids.append(open(vcf.replace(".vcf", "_{}.vcf".format(idx)), "w"))
            f_vcf = open(vcf, "r")
            for line in f_vcf:
                if line.startswith("#CHROM"):
                    values = line.split()
                    header = values[0: 9]
                    for idx in idxs:
                        val = values[9 + idx - 1]
                        new_line = "\t".join(header) + "\t{}\n".format(val)  # re-assemble the line
                        f_ids[idx - 1].write(new_line)
                elif line.startswith("#"):
                    for f in f_ids:
                        f.write(line)
                else:
                    values = line.split()
                    header = values[0: 9]
                    for idx in idxs:
                        val = values[9 + idx - 1]
                        new_line = "\t".join(header) + "\t{}\n".format(val)  # re-assemble the line
                        f_ids[idx - 1].write(new_line)
            f_vcf.close()
            for f in f_ids:
                f.close()


if __name__ == '__main__':
    fire.Fire(split_vcf)
