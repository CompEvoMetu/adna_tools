import lib as adna_lib
import fire
import sys

__version__ = '2021.3.22'  # update also in filter_vcf doc


def filter_vcf(vcf: str, prefix: str, f_maps=None, m_maps=None, chrs=None, x_chr=None, idxs=None,
               interpolate=False, debug=False):
    """Filter VCF, aDNA Tools v.2021.3.22

    Given  an input VCF file and a list of genetic maps  (or a single unique file),  filter the files retaining only
    the  shared SNPs.  Optionally, the genetic map probabilities for SNP locations (of the source VCF file) that are
    not included in the given map can be estimated via interpolation (interpolation=True)
    Examples (ADNA_PATH="/mnt/.../python/packages/adna_tools/"; export ADNA_PATH):

    • Documentation:
        python $ADNA_PATH/filter_vcf.py --help

    • Filter VCF and genetic map with both autosomes and X chromosome:
        python $ADNA_PATH/filter_vcf.py --vcf pops.vcf --prefix filter_pops
        --f_maps female_chr{}.txt --m_maps male_chr{}.txt --x_chr 23

    • Filter VCF and genetic map with only autosomes:
        python $ADNA_PATH/filter_vcf.py --vcf pops_auto.vcf --prefix filter_pops_auto
        --f_maps female_chr{}.txt --m_maps male_chr{}.txt

    • Filter VCF and genetic map with only X chromosome:
        python $ADNA_PATH/filter_vcf.py --vcf pops_x.vcf --prefix filter_pops_x
        --f_maps female_chr{}.txt --m_maps male_chr{}.txt --chrs [] --x_chr 23

    • Interpolate genetic map values given VCF with both autosomes and X chromosome:
        python $ADNA_PATH/filter_vcf.py --vcf pops.vcf --prefix inter_pops
        --f_maps female_chr{}.txt --m_maps male_chr{}.txt --x_chr 23 --interpolate

    • Interpolate genetic map values given VCF with only autosomes:
        python $ADNA_PATH/filter_vcf.py --vcf pops_auto.vcf --prefix inter_pops_auto
        --f_maps female_chr{}.txt --m_maps male_chr{}.txt --interpolate

    • Interpolate genetic map values given VCF with only X chromosome:
        python $ADNA_PATH/filter_vcf.py --vcf pops_x.vcf --prefix inter_pops_x
        --f_maps female_chr{}.txt --m_maps male_chr{}.txt --chrs [] --x_chr 23 --interpolate
    :param str vcf: Input VCF file
    :param str prefix: Output prefix for the filtered VCF and MAP files
    :param str, optional f_maps: Input MAP files for sex-dependent genetic maps  (female):  Multiple files described
    by a pattern-like string, e.g., 'female_genetic_map_chr{}.txt'
    :param str, optional m_maps: Input MAP files for sex-dependent genetic maps (male): Multiple files described  by
    a pattern-like string, e.g., 'male_genetic_map_chr{}.txt'
    :param list, optional chrs: List of  chromosomes to be  considered for the genetic map sequences.  By default, it
    considers autosomes as a list of integers from 1 to 22 and the X chromosome as the integer 23  (however this can
    be changed by specifying the parameter x_chr)
    :param x_chr: symbol associated with the X chromosome (default None, i.e. not considered)
    :param [int], optional idxs:  Column indices  to identify,  within the  genetic map inputs, the chromosome,  SNP
    position and cM values respectively (default [0, 1, 3])
    :param bool, optional interpolate: Flag to apply interpolation (default False)
    :param bool, optional debug: Flag to perform additional safety check for debugging purpose (default False)"""

    # init variables
    m_line = ""
    if chrs is None:
        chrs = list(range(1, 23))
    if idxs is None:
        idxs = [0, 1, 3]

    if x_chr is not None:
        chrs.append(x_chr)

    if interpolate:
        vcf_out = vcf
    else:
        vcf_out = "{}.vcf".format(prefix)
    map_out = "{}.map".format(prefix)

    print("\nInput VCF file: {}".format(vcf))
    if "{}" not in f_maps or "{}" not in m_maps:
        raise ValueError("Single input genetic map file not implemented yet.")
    else:
        print("Reference MAP files:")
        print("          Male: {}".format(m_maps))
        print("          Female: {}".format(f_maps))

    print("Output file(s):")
    if not interpolate:
        print("          {}".format(vcf_out))
    print("          {}".format(map_out))

    # default columns for maps (header)
    map_cols = ["#chr", "pos", "male_cM", "female_cM"]

    snps, snps_dict = adna_lib.snp_list(file=vcf, x_chr=x_chr)  # list of SNPs from the input VCF file

    if debug:
        idx_snps = 0
        eot = False
        match = 0
        for idx in chrs:  # for each chromosome
            chro = str(idx)
            positions = snps_dict[chro]
            for p in positions:
                if snps[idx_snps][0] == idx and snps[idx_snps][1] == int(p):
                    match = match + 1
                    idx_snps = idx_snps + 1
                else:
                    print("\nFound snp_list mismatch.")
                    eot = True
                    break
            if eot:
                break
        print("\nNumber of matched SNPs during snp_list call: {}".format(match))

    print("\nReading genetic map files")
    if interpolate:
        maps_m = {}
        maps_f = {}
        max_len = 0
        prg_n = -1
        for idx in chrs:  # for each chromosome
            prg_n = prg_n + 1
            m_file = m_maps.format(idx)
            f_file = f_maps.format(idx)
            txt = "'{}' and '{}'".format(m_file, f_file)
            max_len = max(max_len, len(txt))
            adna_lib.print_progress_bar(prg_n, len(chrs), txt)
            [f_map, f_dict] = adna_lib.snp_list(file=f_file, chr_idx=idxs[0], pos_idx=idxs[1], val_idx=idxs[2],
                                                header=1, x_chr=x_chr)
            if not str(idx) == str(x_chr):
                [m_map, m_dict] = adna_lib.snp_list(file=m_file, chr_idx=idxs[0], pos_idx=idxs[1], val_idx=idxs[2],
                                                    header=1, x_chr=x_chr)
                for idx_map in range(len(m_map)):
                    if not m_map[idx_map][0] == f_map[idx_map][0]:
                        sys.exit("\nMale and female genetic maps have different set of SNPs (changed chromosome).")
                    elif not m_map[idx_map][1] == f_map[idx_map][1]:
                        sys.exit("\nMale and female genetic maps have different set of SNPs (different positions).")
            else:
                f_prob = f_dict[str(idx)]
                m_prob = []
                for idx_prob in range(len(f_prob)):
                    m_prob.append((f_prob[idx_prob][0], "0"))
                m_dict = {
                    str(idx): m_prob
                }

            maps_m.update(m_dict)
            maps_f.update(f_dict)

        txt = " " * max_len
        adna_lib.print_progress_bar(len(chrs), len(chrs), "OK" + txt)
        print("\n")

        map_content = []
        tot = 0
        max_len = 0
        prg_n = -1
        print("\nInterpolating the source VCF file")
        for vcf_chr, vcf_snps in snps_dict.items():  # for each chromosome and associated SNPs list
            prg_n = prg_n + 1
            txt = "Chr {} ".format(vcf_chr)
            max_len = max(max_len, len(txt))
            adna_lib.print_progress_bar(prg_n, len(chrs), txt)

            m_snps = maps_m[vcf_chr]  # male
            f_snps = maps_f[vcf_chr]  # female
            map_idx = 0
            for vcf_snp in vcf_snps:  # snps of the chromosome
                tot = tot + 1

                # if the position is bigger than the current reference keep moving to the next reference
                # unless you reach the end of the list
                while (map_idx < len(m_snps)) and (int(vcf_snp) > int(m_snps[map_idx][0])):
                    map_idx = map_idx + 1

                # interpolate
                if map_idx >= len(m_snps) - 1 and int(vcf_snp) > int(m_snps[-1][0]):  # last entry
                    map_content.append([vcf_chr, vcf_snp, m_snps[-1][1], f_snps[-1][1]])
                elif int(vcf_snp) == int(m_snps[map_idx][0]):  # same position of genetic map
                    map_content.append([vcf_chr, vcf_snp, m_snps[map_idx][1], f_snps[map_idx][1]])
                    map_idx = map_idx + 1
                else:  # smaller than current genetic map position
                    if map_idx == 0:  # first genetic map entry
                        map_content.append([vcf_chr, vcf_snp, m_snps[map_idx][1], f_snps[map_idx][1]])
                    else:
                        # interpolate
                        m_upper_p = float(m_snps[map_idx][1])  # upper limit position
                        m_lower_p = float(m_snps[map_idx - 1][1])  # lower limit position

                        f_upper_p = float(f_snps[map_idx][1])  # upper limit probability
                        f_lower_p = float(f_snps[map_idx - 1][1])  # lower limit probability

                        # compute coefficient for the current position
                        coeff = (float(vcf_snp) - float(m_snps[map_idx - 1][0])) / (
                                float(m_snps[map_idx][0]) - float(m_snps[map_idx - 1][0]))

                        # estimate probabilities according to the displacement in the interval
                        if m_lower_p == m_upper_p:
                            m_p = m_lower_p
                        else:
                            m_p = m_lower_p + coeff * (m_upper_p - m_lower_p)
                            if debug and m_p <= m_lower_p or m_p >= m_upper_p:
                                print("\nCurrent position={}\tcM={}".format(vcf_snp, m_p))
                                print("Lower reference={}\tcM={}".format(m_snps[map_idx][0], m_lower_p))
                                print("Upper reference={}\tcM={}".format(m_snps[map_idx + 1][0], m_upper_p))

                        if f_lower_p == f_upper_p:
                            f_p = f_lower_p
                        else:
                            f_p = f_lower_p + coeff * (f_upper_p - f_lower_p)
                            if debug and f_p <= f_lower_p or f_p >= f_upper_p:
                                print("\nCurrent position={}\tcM={}".format(vcf_snp, f_p))
                                print("Lower reference={}\tcM={}".format(f_snps[map_idx][0], f_lower_p))
                                print("Upper reference={}\tcM={}".format(f_snps[map_idx + 1][0], f_upper_p))

                        map_content.append([vcf_chr, vcf_snp, str(m_p), str(f_p)])
        for idx_cnt in range(len(snps)):
            snp = snps[idx_cnt]

            try:
                check_0 = snp[0] == int(map_content[idx_cnt][0])
            except ValueError:
                check_0 = snp[0] == str(map_content[idx_cnt][0])

            try:
                check_1 = snp[1] == int(map_content[idx_cnt][1])
            except ValueError:
                check_1 = snp[1] == str(map_content[idx_cnt][1])

            if not check_0:
                raise ValueError("\nMale and female genetic maps have different set of SNPs (changed chromosome).")
            elif not check_1:
                raise ValueError("\nMale and female genetic maps have different set of SNPs (different positions).")

        txt = " " * max_len
        adna_lib.print_progress_bar(len(chrs), len(chrs), "OK" + txt)
        print("\n")

        # return map_content
        file_out_map = open(map_out, "w")
        header = True
        for vals in map_content:  # for each line
            if header:
                map_line = "\t".join(map_cols)
                map_line = map_line + "\n"
                file_out_map.write(map_line)
                header = False
            map_line = "\t".join(vals)
            map_line = map_line + "\n"
            file_out_map.write(map_line)
        file_out_map.close()
    else:
        map_data = []
        prg_n = -1
        max_len = 0
        for idx in chrs:  # for each chromosome
            prg_n = prg_n + 1
            chro = str(idx)
            positions = snps_dict[chro]
            idx_pos = 0

            m_file = m_maps.format(idx)
            f_file = f_maps.format(idx)
            txt = "'{}' and '{}'".format(m_file, f_file)
            max_len = max(max_len, len(txt))
            adna_lib.print_progress_bar(prg_n, len(chrs), txt)
            f_file_in = open(f_file, "r")  # open the female reference file

            if not str(idx) == str(x_chr):
                m_file_in = open(m_file, "r")  # open the male reference file
            else:
                m_file_in = None  # for X chromosome, the genetic map probability for males is always set to 0

            header = True
            eol = False
            for f_line in f_file_in:  # for each line

                if not str(idx) == str(x_chr):
                    m_line = m_file_in.readline()

                if header:  # first line is a header
                    header = False
                else:
                    # select the chromosome and position of the current line
                    # default chr   pos   rate   cM

                    f_values = f_line.split()

                    f_chr = f_values[idxs[0]]
                    f_pos = f_values[idxs[1]]
                    f_cm = f_values[idxs[2]]

                    if not str(idx) == str(x_chr):
                        m_values = m_line.split()
                        m_chr = m_values[idxs[0]]
                        m_pos = m_values[idxs[1]]
                        m_cm = m_values[idxs[2]]

                        if not m_chr == f_chr:
                            raise ValueError(
                                "\nMale and female genetic maps have different set of SNPs (changed chromosome).")
                        elif not m_pos == f_pos:
                            raise ValueError(
                                "\nMale and female genetic maps have different set of SNPs (different positions).")
                    else:
                        # m_chr = f_values[idxs[0]]
                        m_pos = f_values[idxs[1]]
                        m_cm = 0

                    cont = False
                    while not cont:
                        if int(m_pos) == int(positions[idx_pos]):
                            if f_file is not None:
                                map_data.append([chro, positions[idx_pos], str(m_cm), str(f_cm)])
                            else:
                                map_data.append([chro, positions[idx_pos], str(m_cm)])
                            idx_pos = idx_pos + 1
                            cont = True
                        elif int(m_pos) > int(positions[idx_pos]):
                            if f_file is not None:
                                map_data.append([chro, positions[idx_pos], None, None])
                            else:
                                map_data.append([chro, positions[idx_pos], None])
                            idx_pos = idx_pos + 1
                        else:
                            cont = True

                        if idx_pos == len(positions):
                            eol = True
                            cont = True
                if eol:
                    break
            while idx_pos < len(positions):
                if f_file is not None:
                    map_data.append([chro, positions[idx_pos], None, None])
                else:
                    map_data.append([chro, positions[idx_pos], None])
                idx_pos = idx_pos + 1
            if not str(idx) == str(x_chr):
                m_file_in.close()
            f_file_in.close()

        txt = " " * max_len
        adna_lib.print_progress_bar(len(chrs), len(chrs), "OK" + txt)
        print("\n")
        if debug:
            print("Total number of added SNPs for 'map_data': {}".format(len(map_data)))
            print("Total number of SNPs for 'snps': {}".format(len(snps)))

            idx_snps = 0
            eot = False
            match = 0
            for idx in chrs:  # for each chromosome
                chro = str(idx)
                positions = snps_dict[chro]
                for p in positions:
                    if int(map_data[idx_snps][0]) == idx and int(map_data[idx_snps][1]) == int(p):
                        match = match + 1
                        idx_snps = idx_snps + 1
                    else:
                        print(" - snp filtering mismatch.")
                        eot = True
                        break
                if eot:
                    break
            print("Number of matched checks during filtering: {}\n".format(match))

        missing = 0
        found = 0
        for m in map_data:
            if m[2] is None:
                missing = missing + 1
            else:
                found = found + 1
        print("SNPs Summary")
        print("Not overlapping: {}".format(missing))
        print("Found matches: {}".format(found))
        print("Total number: {}".format(found + missing))

        file_in = open(vcf, "r")
        file_out = open(vcf_out, "w")
        file_out_map = open(map_out, "w")
        header = True
        idx_map = 0
        skip = 0
        incl = 0
        for line in file_in:  # for each line
            if header:
                map_line = "\t".join(map_cols)
                map_line = map_line + "\n"
                file_out_map.write(map_line)
                header = False

            if line.startswith("#"):  # comment line, rewrite it
                file_out.write(line)
            else:
                # select the chromosome and position of the current line
                values = line.split()
                line_chromosome = int(values[0])
                line_position = int(values[1])
                if int(map_data[idx_map][0]) == line_chromosome and int(map_data[idx_map][1]) == line_position:
                    if map_data[idx_map][2] is None:
                        skip = skip + 1
                    else:
                        incl = incl + 1
                        file_out.write(line)  # write it on file
                        map_line = "\t".join(map_data[idx_map])
                        map_line = map_line + "\n"
                        file_out_map.write(map_line)
                    idx_map = idx_map + 1
                else:
                    print("\nUnexpected mismatch error, run the function in debug mode (debug=True).")
                    break
        if debug:
            print("\nSNPs Summary for output files")
            print("Removed: {}".format(skip))
            print("Included: {}".format(incl))
            print("Total number: {}".format(skip + incl))
        file_in.close()
        file_out.close()
        file_out_map.close()

    sys.stdout.write("\nVerifying output... ")
    file_vcf = open(vcf_out, "r")
    file_map = open(map_out, "r")
    vcf_line = file_vcf.readline()
    map_line = file_map.readline()
    mismatch = False
    while vcf_line and not mismatch:
        while vcf_line.startswith("#"):
            vcf_line = file_vcf.readline()
        while map_line.startswith("#"):
            map_line = file_map.readline()
        vcf_values = vcf_line.split()
        map_values = map_line.split()
        if vcf_values[0] == map_values[0] and vcf_values[1] == map_values[1]:
            vcf_line = file_vcf.readline()
            map_line = file_map.readline()
        else:
            mismatch = True
    if mismatch:
        sys.stdout.write("KO")
        print(
            "\nUnexpected mismatch, the output files are non consistent. Run the function in debug mode (debug=True).")
    else:
        sys.stdout.write("OK\n")
        if interpolate:
            txt = "Interpolation successfully completed."
        else:
            txt = "Filtering successfully completed."
        print(txt)
    file_vcf.close()
    file_map.close()

    if debug and interpolate:
        sys.stdout.write("\nTesting output map... ")
        adna_lib.interpolation_test(map_file=map_out, f_maps=f_maps, m_maps=m_maps, x_chr=str(x_chr))
        sys.stdout.write("OK\n")


if __name__ == '__main__':
    fire.Fire(filter_vcf)
