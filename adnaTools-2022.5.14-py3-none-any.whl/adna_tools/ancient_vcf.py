from pathlib import Path
import lib as a_lib
import errno
import fire
import os

__version__ = '2021.3.22'  # update also in ancient_vcf doc


def ancient_vcf(vcf_file: str, div_snp="/"):
    """Ancient VCF, aDNA Tools v.2021.3.22

    Given a VCF input file containing multiple ancient samples, it creates a folder (with same name of the input file)
    where it stores multiple VCF files each containing couples of individuals to be compared
    Example: vcf_file = "ancient_sample.vcf" containing 4 ancient individuals (0, 1, 2, 3).
             A folder "ancient_sample" is created with six files (ancient_sample_0_1.vcf, ..., ancient_sample_2_3.vcf)
             each containing the selected samples with the shared SNPs and with no missing values.
             Note: The created VCF files will follow the phased format (i.e., "|" separator) and additional information
             associated with the SNPs will be automatically discarded (e.g., "0|0:info" the ":info" is dropped)
    :param str vcf_file: VCF files containing ancient samples
    :param str, optional div_snp: Separator for phased or unphased SNPs ('|' or '/'). Default is '/'"""

    print("\nSplitting ancient VCF file...")
    print("VCF file: {}".format(vcf_file))

    file_name = Path(vcf_file).stem  # use the filename as name for the folder to create

    # create the folder with the given name, if it already exists gives error
    try:
        os.makedirs(file_name)
    except OSError as e:
        if e.errno == errno.EEXIST:
            msg = "The folder '{}' already exists!".format(file_name)
            raise FileExistsError(msg)
        else:
            raise

    file_in = open(vcf_file, "r")

    # initialize variables
    header = []
    file_out = []
    n = None
    n_cmb = None

    for line in file_in:  # for each line
        if line.startswith("#CHROM"):  # initialize the output VCF files
            values = line.split()
            n = len(values) - 9
            n_cmb = int(n * (n - 1) / 2)
            idx_1 = 0
            while idx_1 < n - 1:  # prepare output file(s)
                idx_2 = idx_1 + 1
                while idx_2 < n:

                    # create the file
                    an_file = os.path.join(".", file_name, "{}_{}_{}.vcf".format(file_name, idx_1, idx_2))
                    file_out.append(open(an_file, "w"))

                    # add all the header lines
                    for header_line in header:
                        file_out[-1].write(header_line)

                    # add the header line with the column names and the two sample IDs that will be stored
                    out_values = values[0:9] + [str(idx_1), str(idx_2)]
                    out_line = "\t".join(out_values)
                    out_line = out_line + "\n"
                    file_out[-1].write(out_line)

                    idx_2 += 1
                idx_1 += 1
        elif line.startswith("#"):  # store the header line to be added later on to each newly created file
            header.append(line)
        else:
            values = line.split()
            header = values[0:9]
            snps = values[9:]
            idx_cmb = 0
            idx_1 = 0
            while idx_1 < n - 1:  # consider each combination between individuals
                idx_2 = idx_1 + 1
                while idx_2 < n:
                    out_values = header
                    snp_1 = a_lib.clean_snp(snps[idx_1], div_snp=div_snp)
                    snp_2 = a_lib.clean_snp(snps[idx_2], div_snp=div_snp)

                    # fix unexpected SNPs
                    if "." in snp_1 and not snp_1 == ".|.":
                        print(snp_1)
                        snp_values = snp_1.split("|")
                        if snp_values[0] == ".":
                            snp_1 = "{0}|{0}".format(snp_values[1])
                        else:
                            snp_1 = "{0}|{0}".format(snp_values[0])
                    if "." in snp_2 and not snp_2 == ".|.":
                        print(snp_2)
                        snp_values = snp_2.split("|")
                        if snp_values[0] == ".":
                            snp_2 = "{0}|{0}".format(snp_values[1])
                        else:
                            snp_2 = "{0}|{0}".format(snp_values[0])

                    # if there aren't missing values you can write, otherwise skip
                    if not snp_1 == ".|." and not snp_2 == ".|.":

                        # reformat the SNPs with the original phase/unphased separator
                        snp_1 = "{}{}{}".format(snp_1[0], div_snp, snp_1[2])
                        snp_2 = "{}{}{}".format(snp_2[0], div_snp, snp_2[2])

                        out_values = out_values + [snp_1, snp_2]
                        out_line = "\t".join(out_values)
                        out_line = out_line + "\n"
                        file_out[idx_cmb].write(out_line)

                    idx_2 += 1
                    idx_cmb += 1
                idx_1 += 1

    file_in.close()
    for idx_out in range(n_cmb):  # close output file(s)
        file_out[idx_out].close()


if __name__ == '__main__':
    fire.Fire(ancient_vcf)
