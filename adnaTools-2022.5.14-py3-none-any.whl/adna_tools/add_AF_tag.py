import lib as a_lib
import fire

__version__ = '2021.3.22'  # update also in add_tag doc


def add_tag(vcf_file: str, af_file: str):
    """Add AF TAG to VCF, aDNA Tools v.2021.3.2

    Add the alternate frequency ngsRelate TAG to the given VCF file.
    The frequency files is expected to contain one value per line (it shouldn't contain any additional information)
    :param vcf_file: The VCF file where the TAG will be added
    :param af_file: The alternate frequency (AF) values"""

    a_lib.maf2vcf(af_file, vcf_file)


if __name__ == '__main__':
    fire.Fire(add_tag)
