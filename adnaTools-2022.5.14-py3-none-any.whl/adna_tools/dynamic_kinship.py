import fire
import lib as adna_lib
import matplotlib.pyplot as plt

__version__ = '2021.3.22'  # update also in dynamic_asc doc


# noinspection PyUnboundLocalVariable,PyBroadException
def dynamic_kinship(vcf_file: str, prefix: str, win_length: int, win_shift: int, chromosomes=None, idx_rel=None,
                    labels=None, use_labels=True, extension="pdf", phased=None, plots=True):
    """Dynamic Kinship, aDNA Tools v.2021.3.22

    For a VCF file it computes the dynamic allele sharing coefficient and the mismatch coefficient, given also specific
    window length and shift, among all samples in the file for a given set of chromosome (one figure and logging file
    per chromosome)
    :param str vcf_file: Input file from which computing the dynamic allele sharing coefficient
    :param str prefix: Prefix for the output files (plot image and logging file)
    :param int win_length: Length (in terms of SNPs) of the window
    :param int win_shift: Shift (in terms of SNPs) of the window
    :param str or [str], optional chromosomes: Selected chromosome to consider for the plot
    :param [int], optional idx_rel: Indices of interest to be plotted (default all combinations of samples)
    :param [str], optional labels: Labels associated with each combination of samples (default IDs of the samples)
    :param bool, optional use_labels: By default (use_labels=True) the columns in the log file(s) will use the given
    labels or, if not passed as parameters (i.e., labels=None) will use the IDs found in the source file
    (e.g., "IDn - IDm"). If use_labels is set to False, the columns in the log file(s) will be named using the indices
    (e.g., "(0,1)" )
    NOTE: If the optional parameter labels is defined then this flag is ignored and the given labels are used
    :param str, optional extension: Plot image extension (default "pdf")
    :param bool, optional phased: If set, it assumes the data to be phased. Default behavior determined automatically
    , i.e., phased=None
    :param bool, optional plots: If set, the ASC/MSM plots are also generated (default behavior)"""

    if phased is None:
        print("\nDefine data type by looking at the first sample:")
        file_in = open(vcf_file, "r")
        for line in file_in:
            if not line.startswith("#"):
                values = line.split("\t")
                if "|" in values[9]:
                    phased = True
                    msg = "   The VCF file has phased samples"
                elif "/" in values[9]:
                    phased = False
                    msg = "   The VCF file has unphased samples"
                elif len(adna_lib.clean_snp(values[9])) == 1:  # single value SNPs, i.e., 0s or 1s
                    phased = False
                    msg = "   The VCF file has unphased samples"
                else:
                    file_in.close()
                    msg = "Couldn't determine if the input VCF file contains phased or unphased data. Please set the " \
                          "'phased' flag accordingly. "
                    raise TypeError(msg)
                file_in.close()
                break
        print(msg)

    print("Analyzing data...")
    asc = adna_lib.dynamic_kinship(vcf_file=vcf_file, win_len=win_length, win_shift=win_shift, phased=phased)

    msm = asc[1]
    asc = asc[0]

    discard_asc = False
    if type(asc) is list and type(asc[0]) is str and asc[0] == "DISCARD":  # no freq values were given, discard results
        discard_asc = True
        asc = asc[1]

    if chromosomes is None:  # select all available chromosomes
        chromosomes = []
        for key, _ in asc.items():
            if key != "id" and key != "idx":
                chromosomes.append(key)
    elif type(chromosomes) is int:  # only one chromosome indicated as integer, convert to list of strings
        chromosomes = [str(chromosomes)]
    elif type(chromosomes) is str:  # only one chromosome indicated as str, convert to list of strings
        chromosomes = [chromosomes]
    else:  # list of chromosome, convert to list of strings
        for idx in range(len(chromosomes)):
            chromosomes[idx] = str(chromosomes[idx])

    if type(idx_rel) is int:
        idx_rel = [idx_rel]

    for chromosome in chromosomes:

        # select ASC and MSM data pertaining to the chromosome of interest
        asc_data = asc[chromosome]
        msm_data = msm[chromosome]

        # idx_rel identify the indices for the selected couples, if not defined select all the available values
        if idx_rel is None:
            try:
                idx_rel = list(range(len(msm_data[0][1])))
            except:
                idx_rel = [0]

        # initialize the labels used for the exported files
        if labels is None:
            ids = asc["id"]  # IDs of the samples
            all_labels = []
            labels = []
            if use_labels:
                for idxs in asc["idx"]:
                    all_labels.append("{} - {}".format(ids[idxs[0]], ids[idxs[1]]))
                for idx_sel in idx_rel:
                    labels.append(all_labels[idx_sel])
            else:
                for idxs in asc["idx"]:
                    all_labels.append("({},{})".format(idxs[0], idxs[1]))
                for idx_sel in idx_rel:
                    labels.append(all_labels[idx_sel])
        elif type(labels) is str:
            labels = labels.strip("][").split(',')

        # export ASC values for the current chromosome
        if not discard_asc:
            file_log = open("{}_{}_ASC.log".format(prefix, chromosome), "w")
            txt_header = "#Window ID\tSamples Size"
            for label in labels:
                txt_header = "{}\t{}".format(txt_header, label)
            txt_header = txt_header + "\n"
            file_log.write(txt_header)
            win_id = 1
            for win_data in asc_data:
                txt_line = "{}\t{}".format(win_id, win_data[0])
                for idx in idx_rel:
                    values = win_data[1]
                    if type(values) is tuple:
                        values = values[idx]
                    txt_line = "{}\t{}".format(txt_line, values)
                txt_line = txt_line + "\n"
                file_log.write(txt_line)
                win_id += 1
            file_log.close()

        # export MSM values for the current chromosome
        file_log = open("{}_{}_MSM.log".format(prefix, chromosome), "w")
        txt_header = "#Window ID\tSamples Size"
        for label in labels:
            txt_header = "{}\t{}".format(txt_header, label)
        txt_header = txt_header + "\n"
        file_log.write(txt_header)
        win_id = 1
        for win_data in msm_data:
            txt_line = "{}\t{}".format(win_id, win_data[0])
            for idx in idx_rel:
                values = win_data[1]
                if type(values) is tuple:
                    values = values[idx]
                txt_line = "{}\t{}".format(txt_line, values)
            txt_line = txt_line + "\n"
            file_log.write(txt_line)
            win_id += 1
        file_log.close()

        if plots:
            # plot the points of interest and export data for ASC
            if not discard_asc:
                # x-axis values: from 1 to M (with M number of windows)
                x = list(range(1, len(asc_data) + 1))

                # assemble the data points y: the number of total comparisons between the individuals, i.e., N*(N-1)/2
                # and for each i, y[i] is a list containing M (number of windows) values
                y_asc = []

                try:
                    asc_n_data = len(asc_data[0][1])
                except:
                    asc_n_data = 1

                for idx1 in range(asc_n_data):
                    tmp_asc = []
                    for idx2 in range(len(asc_data)):
                        if type(asc_data[idx2][1]) is tuple:
                            tmp_asc.append(asc_data[idx2][1][idx1])
                        else:
                            tmp_asc.append(asc_data[idx2][1])
                    y_asc.append(tmp_asc)

                plt.figure()
                for idx in idx_rel:
                    cur_x = x.copy()
                    cur_y_asc = y_asc[idx].copy()
                    stop = False
                    while not stop:
                        try:
                            index = cur_y_asc.index("-")
                            cur_x.pop(index)
                            cur_y_asc.pop(index)
                        except ValueError:
                            stop = True
                    plt.scatter(cur_x, cur_y_asc, alpha=0.5, marker="o")
                plt.xlabel('# Window')  # naming the x-axis
                plt.ylabel('ASC')  # naming the y-axis
                plt.title('Dynamic ASC (Chr: {}; Window: Length = {:,}, Shift = {:,})'.format(
                    chromosome, win_length, win_shift))
                _ = plt.legend(labels, title="Relationship", bbox_to_anchor=(1.05, 0.26))
                fig = plt.gcf()
                fig.savefig("{}_{}_ASC.{}".format(prefix, chromosome, extension), dpi=300, bbox_inches="tight")
                plt.close()

            # plot the points of interest and export data for MSM

            # x-axis values: from 1 to M (with M number of windows)
            x = list(range(1, len(msm_data) + 1))

            # assemble the data points y: the number of total comparisons between the individuals, i.e., N*(N-1)/2
            # and for each i, y[i] is a list containing M (number of windows) values
            y_msm = []

            try:
                msm_n_data = len(msm_data[0][1])
            except:
                msm_n_data = 1

            for idx1 in range(msm_n_data):
                tmp_msm = []
                for idx2 in range(len(msm_data)):
                    if type(msm_data[idx2][1]) is tuple:
                        tmp_msm.append(msm_data[idx2][1][idx1])
                    else:
                        tmp_msm.append(msm_data[idx2][1])
                y_msm.append(tmp_msm)

            plt.figure()
            for idx in idx_rel:
                cur_x = x.copy()
                cur_y_msm = y_msm[idx].copy()
                stop = False
                while not stop:
                    try:
                        index = cur_y_msm.index("-")
                        cur_x.pop(index)
                        cur_y_msm.pop(index)
                    except ValueError:
                        stop = True
                plt.scatter(cur_x, cur_y_msm, alpha=0.5, marker="o")
            plt.xlabel('# Window')  # naming the x-axis
            plt.ylabel('Mismatch Coefficient')  # naming the y-axis
            plt.title('Dynamic Mismatch Coefficient (Chr: {}; Window: Length = {:,}, Shift = {:,})'.format(
                chromosome, win_length, win_shift))
            _ = plt.legend(labels, title="Relationship", bbox_to_anchor=(1.05, 0.26))
            fig = plt.gcf()
            fig.savefig("{}_{}_MSM.{}".format(prefix, chromosome, extension), dpi=300, bbox_inches="tight")
            plt.close()


if __name__ == '__main__':
    fire.Fire(dynamic_kinship)
