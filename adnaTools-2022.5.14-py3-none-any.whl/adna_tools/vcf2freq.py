import lib as adna_lib
import fire

__version__ = '2021.3.22'  # update also in vcf2freq doc


def vcf2freq(filename: str, prefix: str, only_frq=False):
    """VCF2Freq, aDNA Tools v.2021.3.2

    Given a VCF file or a text file containing a list of VCF files (one filename per line), it estimates the minimum
    allele frequency (MAF) and alternate allele frequency values for each SNP position. Alongside these values
    the script also generates LOG and ERR files with the number of available samples at each SNP position for each
    observed value (LOG listing all the details, ERR only details pertaining to discarded SNPs). Four output files will
    be created: {prefix}MAF.frq, {prefix}ALT.frq, {prefix}FRQ.log, {prefix}FRQ.err for MAF values, alternate frequency
    values, log and error files respectively. Each FRQ file will contain three columns: CHR (chromosome),
    POS (SNP position), FRQ (frequency value) unless the flag 'only_frq' is set to True, in which case only frequency
    values will be saved (by default 'only_frq' is set to False).
    The LOG and ERR files will contain eight columns: CHR (chromosome), POS (SNP position), REF (the reference allele),
    ALT (the alternate allele), N_REF (total number of samples for the reference allele), N_ALT (total number of samples
    for the alternate allele), STATUS (indicating if the SNP was retained in the final output, i.e., OK (only LOG),
    or it was discarded due to reference/alternate/non bi-allele inconsistencies or unknown values, INFO (additional
    information, used to provide the list of observed SNPs and their occurrences in discarded samples).
    When a SNP is discarded the REF, ALT, N_REF, N_ALT columns are filled with '-'
    :param str filename: Text file containing the list of VCF files to be merged
    :param str prefix: Output filename
    :param bool, optional only_frq: Flag that allows, if set, to only store the frequency values in the FRQ files"""

    if ".vcf" in filename.lower():
        msg = "Analyzing VCF file..."
    else:
        msg = "Analyzing VCF files..."
    print(msg)

    log_header = "CHR\tPOS\tREF\tALT\tN_REF\tN_ALT\tSTATUS\tINFO\n"
    maf_header = None
    alt_header = None
    if not only_frq:
        maf_header = "CHR\tPOS\tMAF\n"
        alt_header = "CHR\tPOS\tALT\n"

    ins = open_input(filename)  # open input files (read mode)
    log_out = open(prefix + "FRQ.log", "w")  # open LOG output file (write mode)
    err_out = open(prefix + "FRQ.err", "w")  # open ERR output file (write mode)
    maf_out = open(prefix + "MAF.frq", "w")  # open MAF output file (write mode)
    alt_out = open(prefix + "ALT.frq", "w")  # open ALT output file (write mode)
    log_out.write(log_header)
    err_out.write(log_header)
    if maf_header is not None:  # write the header of the freq files if necessary
        maf_out.write(maf_header)
        alt_out.write(alt_header)

    read_snp_lines(ins, maf_out, alt_out, log_out, err_out, only_frq)  # analyze the SNPs lines

    close_files(ins)  # close all the used resources
    log_out.close()
    err_out.close()
    maf_out.close()
    alt_out.close()


def open_input(filename: str) -> []:
    """
    Load VCF files added to the text file
    :param filename: Input file from which the list of VCF files is read
    :return: An array of file handlers"""

    vcfs = []
    if ".vcf" in filename.lower():
        vcfs.append(open(filename.rstrip(), "r"))
    else:
        txt = open(filename.rstrip(), "r")
        for filename in txt:
            curr_file = filename.strip('\n').rstrip()
            if len(curr_file) > 0:
                vcfs.append(open(curr_file, "r"))
        txt.close()

    return vcfs


def close_files(ins: []):
    """
    Close all the files
    :param ins: Input file handlers"""

    for file_in in ins:
        file_in.close()


# noinspection PyUnresolvedReferences,PyTypeChecker,PyUnboundLocalVariable
def read_snp_lines(ins: [], maf_out, alt_out, log_out, err_out, only_frq: bool):
    """
    Read the VCF lines for each SNP
    :param ins: Input file handlers
    :param maf_out: Minor allele frequency file
    :param alt_out: Alternate allele frequency file
    :param log_out: Logging file for all the details of the process
    :param err_out: Error file for the discarded SNPs
    :param bool, optional only_frq: Store only the frequency values in the FRQ files"""

    eof = len(ins) * [False]  # keeps track of EOF (end of file) for each input
    stop = all(eof)  # flag to stop the process once all inputs are EOF
    chromosome = 0  # keep track of the current chromosome
    snps = len(ins) * [None]  # SNPs line from each input
    print("\nChromosome")
    while not stop:
        for idx_in in range(len(ins)):  # loop over each input file
            if not eof[idx_in] and snps[idx_in] is None:  # if the file is not over, and we need to read a new line
                line = ins[idx_in].readline()
                if not line:
                    eof[idx_in] = True
                while not eof[idx_in] and line.startswith("#"):  # skip additional commented lines
                    line = ins[idx_in].readline()
                    if not line:
                        eof[idx_in] = True
                if not eof[idx_in]:  # found useful line
                    snps[idx_in] = line.strip('\n').split("\t")

        # now we have a line for each of the input file, let's choose the chromosome+position of interest
        # (unless we finished with all the files)
        stop = all(eof)
        if not stop:
            candidate_found = False  # flag to check if at least one candidate was found
            next_chromosome = None
            next_position = None
            next_reference = None
            next_alternate = None
            position = None
            reference = None  # keep the values for the selected position to verify consistency across VCFs
            alternate = None
            while not candidate_found:
                for idx_line in range(len(snps)):
                    if not eof[idx_line]:
                        values = snps[idx_line]
                        if chromosome == values[0].lower().replace("x", "23"):  # it is a candidate, check its position
                            candidate_found = True
                            if not position:
                                position = int(values[1])
                                reference = [values[3]]
                                alternate = [values[4]]
                            elif int(values[1]) < position:
                                position = int(values[1])
                                reference = [values[3]]
                                alternate = [values[4]]
                        else:  # not a current candidate, check potential for next chromosome candidate
                            check_chr = int(values[0].lower().replace("x", "23"))
                            if not next_chromosome or check_chr < next_chromosome:
                                next_chromosome = check_chr
                                next_position = int(values[1])
                                next_reference = [values[3]]
                                next_alternate = [values[4]]
                            elif check_chr == next_chromosome:
                                if int(values[1]) < next_position:
                                    next_position = int(values[1])
                                    next_reference = [values[3]]
                                    next_alternate = [values[4]]

                if not candidate_found:  # no candidate for the current chromosome, we need to switch to a new one
                    candidate_found = True
                    chromosome = next_chromosome
                    position = next_position
                    reference = next_reference
                    alternate = next_alternate
                    print(chromosome)

                chromosome = str(chromosome)
                position = str(position)

            samples = []
            for idx_line in range(len(snps)):
                if not eof[idx_line]:
                    values = snps[idx_line]
                    if values[0].lower().replace("x", "23") == chromosome and values[1] == position:  # use this entry
                        reference.append(values[3])  # keep track of all reference and alternate values
                        if values[4] == ".":  # alternate is missing_value
                            for idx_ind in range(9, len(values)):  # replace alternate value with missing value
                                tmp = adna_lib.clean_snp(values[idx_ind])
                                if "1" in tmp:
                                    tmp = tmp.replace("1", ".")
                                    if len(tmp) == 1:
                                        values[idx_ind] = tmp
                                    else:
                                        new_value = tmp[0] + values[idx_ind][1] + tmp[2]
                                        if len(values[idx_ind]) > 3:
                                            new_value = new_value + values[idx_ind][3:]
                                        values[idx_ind] = new_value  # 'values' reference 'snps' which is then updated
                        else:
                            alternate.append(values[4])
                        samples = samples + values[9:]  # store all the samples for the current SNP
                        snps[idx_line] = None  # it has been added, remove its details

            discard = False  # flag to keep track of discarded SNPs

            # Conditions to be satisfied in order to retain a SNP:
            # - Reference allele has unique value (error: the reference allele has multiple values)
            # - Alternate allele has unique (or missing) value (error: the alternate allele has multiple values)
            # - Reference allele has to be defined (error: the reference allele is missing)
            # - Reference and alternate alleles must be different (error: reference and alternate alleles share values)
            # - The SNP has a unique reference and at most a unique alternate value (error: non bi-allelic SNP)
            # - The SNP has values different from 0, 1 or . (error: unexpected non bi-allelic value)
            # - The SNP has missing values for all the analyzed samples (error: all samples have missing values)

            err_msg = []

            # check reference status
            ref = set(reference)
            if "." in ref:
                discard = True
                err_msg.append("the reference allele is missing")
            elif len(ref) > 1:
                discard = True
                err_msg.append("the reference allele has multiple values")
            ref = list(ref)

            # check alternate status
            alt_miss = False
            alt = set(alternate)
            if "." in alt:
                alt.remove(".")
                alt_miss = True
            if len(alt) > 1:
                discard = True
                err_msg.append("the alternate allele has multiple values")
            alt = list(alt)

            if len(set(ref + alt)) > 2:
                discard = True
                err_msg.append("non bi-allelic SNP")

            if alt:
                tmp = set(ref)
                for alt_val in alt:
                    if alt_val in tmp:
                        discard = True
                        err_msg.append("reference and alternate alleles share values")
                        break

            if discard:  # SNP needs to be discarded, prepare LOG line
                msg_status = "KO:" + ",".join(err_msg)
                msg_ref = "REF:" + ",".join(ref)
                if alt_miss:
                    msg_alt = "ALT:" + ",".join(alt + ["."])
                else:
                    msg_alt = "ALT:" + ",".join(alt)
                msg_info = ";".join([msg_ref, msg_alt])
                log_line = "{}\t{}\t-\t-\t-\t-\t{}\t{}\n".format(chromosome, position, msg_status, msg_info)
                log_out.write(log_line)
                err_out.write(log_line)
            else:  # all ok, prepare FRQs and LOG lines
                # compute the frequencies
                snp_error = False
                ref_samples = 0
                alt_samples = 0
                for sample in samples:
                    tmp = adna_lib.clean_snp(sample)
                    if len(tmp) == 1:
                        if tmp == "0":
                            ref_samples += 1
                        elif tmp == "1":
                            alt_samples += 1
                        elif not tmp == ".":
                            snp_error = True  # unexpected sample value
                            msg_status = "KO:unexpected non bi-allelic value"
                    else:
                        if tmp[0] == "0":
                            ref_samples += 1
                        elif tmp[0] == "1":
                            alt_samples += 1
                        elif not tmp[0] == ".":
                            snp_error = True  # unexpected sample value
                            msg_status = "KO:unexpected non bi-allelic value"

                        if tmp[2] == "0":
                            ref_samples += 1
                        elif tmp[2] == "1":
                            alt_samples += 1
                        elif not tmp[2] == ".":  # unexpected sample value
                            snp_error = True
                            msg_status = "KO:unexpected non bi-allelic value"

                tot_samples = ref_samples + alt_samples
                if tot_samples > 0:
                    ref_freq = ref_samples / tot_samples
                    alt_freq = alt_samples / tot_samples
                else:  # no samples to analyze, all missing values
                    if not snp_error:
                        snp_error = True
                        msg_status = "KO:all samples have missing values"

                ref_str = ref[0]
                if alt_miss:
                    alt_str = "."
                else:
                    alt_str = alt[0]

                if snp_error:
                    # do not store the freq calculation
                    log_line = "{}\t{}\t{}\t{}\t-\t-\t{}\tVALUES:{}\n".format(chromosome,
                                                                              position,
                                                                              ref_str,
                                                                              alt_str,
                                                                              msg_status,
                                                                              "  ".join(samples))
                    log_out.write(log_line)
                    err_out.write(log_line)
                else:
                    log_line = "{}\t{}\t{}\t{}\t{}\t{}\tOK\t-\n".format(chromosome, position,
                                                                        ref_str, alt_str,
                                                                        ref_samples, alt_samples)
                    if only_frq:
                        maf_line = "{}\n".format(min(ref_freq, alt_freq))
                        alt_line = "{}\n".format(alt_freq)
                    else:
                        maf_line = "{}\t{}\t{}\n".format(chromosome, position, min(ref_freq, alt_freq))
                        alt_line = "{}\t{}\t{}\n".format(chromosome, position, alt_freq)

                    log_out.write(log_line)
                    maf_out.write(maf_line)
                    alt_out.write(alt_line)


if __name__ == '__main__':
    fire.Fire(vcf2freq)
