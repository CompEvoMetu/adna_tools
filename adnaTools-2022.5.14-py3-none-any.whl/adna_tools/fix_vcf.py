import lib as adna_lib
import fire

__version__ = '2021.3.22'  # update also in ancient_vcf doc


def fix_vcf(filename: str, prefix="fixed_", missing_values=0, feedback=True):
    """Fix VCF, aDNA Tools v.2021.3.2

    Given a VCF file or a text file containing a list of VCF files (one filename per line),
    it evaluates each input for compatibility issues and if necessary it generates new VCF files (with the additional
    given prefix) where all misplaced entries are rearranged and duplicate entries as well as unsupported SNP lines are
    discarded
    :param str filename: Text file containing the list of VCF files to be checked/fixed (if only one VCF file need to be
    fixed then it can be passed directly)
    :param str, optional prefix: Prefix added to the newly created VCF files
    :param int, optional missing_values: Filter the data in presence of missing data. By default, it filters all
    SNPs having any missing values, i.e., a given SNP is discarded if there is at least one individual with a missing
    value in that position (missing_values=0 as zero missing values are retained). Alternatively, it can be set to 1,
    i.e., the SNP is retained if there is at most a single missing value (e.g., ./1), otherwise it is discarded (e.g.,
    ./.). Finally, if it is set to 2 it retains also SNPs with two missing values, e.g., ./., thus not applying any
    filter. Briefly, the values allowed for the parameter missing_values are either 0, 1, or 2
    :param bool, optional feedback: If set the function provides a more detailed feedback,
    otherwise it will just output minimum information"""

    print("\nFixing VCF file(s)...\n")
    txt_file = filename.lower()
    if not txt_file.endswith(".vcf"):
        txt = open(txt_file, "r")
        for f_name in txt:
            vcf_in = f_name.strip('\n')
            if not vcf_in == "":
                print("\n- '{}'".format(vcf_in))
                vcf_out = "{}{}".format(prefix, vcf_in)
                adna_lib.fix_vcf(vcf_in=vcf_in, vcf_out=vcf_out,
                                 missing_values=missing_values, feedback=feedback)
    else:
        print("\n- '{}'".format(filename))
        vcf_out = "{}{}".format(prefix, filename)
        adna_lib.fix_vcf(vcf_in=filename, vcf_out=vcf_out,
                         missing_values=missing_values, feedback=feedback)


if __name__ == '__main__':
    fire.Fire(fix_vcf)
