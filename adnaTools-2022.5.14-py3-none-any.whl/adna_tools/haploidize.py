import random
import fire
import os

__version__ = '2021.3.22'  # update also in haploidization doc


# noinspection PyUnboundLocalVariable
def haploidization(vcf_file: str, n=1, suffix="_haploid", phased=None, single=True):
    """Haploidize VCF, aDNA Tools v.2021.3.22

    Given a VCF input file, it creates new haploidized version(s)
    :param str vcf_file: Reference samples to be haploidized
    :param int, optional n: The number of different haploidizations (default is 1)
    :param str, optional suffix: If the VCF file is a reference file, the suffix is used to name the haploidized
    versions of it. Default suffix is '_haploid'
    Ex. :   suffix = "_haploid"
            vcf_file = "path/population.vcf"
            n = 3
            Files to be created containing haploidized versions of the population:
            "path/population_haploid1.vcf"
            "path/population_haploid2.vcf"
            "path/population_haploid3.vcf"
    :param bool, optional phased: If set, it assumes the data to be phased. Default behavior determined automatically
    , i.e., phased=None
    :param bool, optional single: Following the haploidization, the value may be stored as single value (i.e., 0 or 1)
    or as a two elements, e.g., 0|0, 1|1. Default is True, i.e. single value"""

    print("\nRunning pseudo-haploidization...")
    print("VCF file: {}".format(vcf_file))
    print("Number of repetitions: {}".format(n))
    print("Output suffix: '{}'".format(suffix))

    if phased is None:
        print("\nDefine data type by looking at the first sample:")
        file_in = open(vcf_file, "r")
        for line in file_in:
            if not line.startswith("#"):
                values = line.split("\t")
                if "|" in values[9]:
                    div_snp = "|"
                    msg = "   The VCF file has phased samples"
                elif "/" in values[9]:
                    div_snp = "/"
                    msg = "   The VCF file has unphased samples"
                else:
                    file_in.close()
                    msg = "Couldn't determine if the input VCF file contains phased or unphased data. Please set the " \
                          "'phased' flag accordingly. "
                    raise TypeError(msg)
                file_in.close()
                break
        print(msg)
    elif phased:
        div_snp = "|"
    else:
        div_snp = "/"

    if single:
        print("NOTE: The output VCF file(s) will contain the single (randomly) selected SNPs, i.e., 1s or 0s.\n")
    else:
        print("NOTE: The output VCF file(s) will contain the single (randomly) selected SNPs stored as two elements, "
              "e.g., '0|0' or '1|1'.\n")
    file_out = []
    for idx_run in range(n):  # prepare output file(s)
        file_name, file_extension = os.path.splitext(vcf_file)
        hap_file = file_name + suffix + "{}".format(idx_run + 1) + file_extension
        file_out.append(open(hap_file, "w"))

    file_in = open(vcf_file, "r")
    for line in file_in:  # for each line
        if line.startswith("#"):
            for idx_run in range(n):  # write header on each output file
                file_out[idx_run].write(line)
        else:
            values = line.split()
            header = values[0:9]
            snps = values[9:]
            for idx_run in range(n):  # for each haploidization run
                haps = []
                for snp in snps:
                    if len(snp) == 1:
                        sel = snp
                    else:
                        spl_snp = snp.split(div_snp)
                        sel = spl_snp[random.getrandbits(1)]
                    if single:
                        haps.append(sel)
                    else:
                        haps.append("{0}{1}{0}".format(sel, div_snp))
                hap_values = header + haps
                hap_line = "\t".join(hap_values)
                hap_line = hap_line + "\n"
                file_out[idx_run].write(hap_line)

    file_in.close()
    for idx_run in range(n):  # close output file(s)
        file_out[idx_run].close()


if __name__ == '__main__':
    fire.Fire(haploidization)
