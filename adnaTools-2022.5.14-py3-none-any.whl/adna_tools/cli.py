import argparse
from . import version


def entry_point():
    parser = argparse.ArgumentParser(
        description='aDNA Tools: A series of scripts to process and analyze ancient DNA data.',
        epilog='''Please, see readme.md for setup and tutorials.''')
    parser.add_argument('--version', action='version',
                        version='%(prog)s {}'.format(version),
                        help='show the version number and exit')

    _ = parser.parse_args()
    # store args instead of _ and do more stuff here if needed


if __name__ == '__main__':
    entry_point()
